(() => {
  'use strict';
  // Panel de diagnostico + ocultador robusto del cuadro verde (NOVA v0.2)
  const VERDE = 'rgb(118, 185, 0)';
  const cnt = { mm: 0, pm: 0, md: 0, mu: 0, pl: 0, tc: 0 };
  let last = '-', verdeInfo = '-';
  const sombras = new Set();
  try {
    const o = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (i) { const r = o.call(this, i); try { sombras.add(r); } catch (_) {} return r; };
  } catch (_) {}
  const reg = (t, k) => window.addEventListener(t, (e) => {
    cnt[k]++;
    last = t + ' ' + (e.pointerType || '') + ' x' + Math.round(e.clientX) + ' y' + Math.round(e.clientY) +
      ' mv' + e.movementX + ',' + e.movementY + ' b' + e.buttons;
  }, true);
  reg('mousemove', 'mm'); reg('pointermove', 'pm'); reg('mousedown', 'md'); reg('mouseup', 'mu');
  window.addEventListener('touchstart', () => cnt.tc++, true);
  document.addEventListener('pointerlockchange', () => cnt.pl++);

  const nombre = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
    (typeof e.className === 'string' && e.className ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');

  function barrer() {
    if (!document.body) return;
    const w = innerWidth, h = innerHeight;
    const raices = [document, ...sombras];
    for (let i = 1; i < 14; i++) for (let j = 1; j < 9; j++) {
      const x = w * i / 14, y = h * j / 9;
      for (const r of raices) {
        let lista = [];
        try { lista = r.elementsFromPoint(x, y); } catch (_) {}
        for (const e of lista) {
          if (e === document.documentElement || e === document.body || e.tagName === 'VIDEO' || e.tagName === 'CANVAS') continue;
          const cs = getComputedStyle(e);
          if (cs.backgroundColor !== VERDE && !/76,\s*185,\s*0/.test(cs.backgroundImage)) continue;
          const rc = e.getBoundingClientRect();
          if (rc.width >= 40 && rc.height >= 40 && rc.width * rc.height < w * h * 0.5 && !e.querySelector('video,canvas')) {
            e.style.setProperty('visibility', 'hidden', 'important');
            e.style.setProperty('display', 'none', 'important');
            verdeInfo = 'oculto ' + nombre(e);
          }
        }
      }
    }
    // que hay en la zona del cuadro (derecha, a media altura)
    try {
      const l = document.elementsFromPoint(w * 0.95, h * 0.39).slice(0, 4).map(nombre);
      if (verdeInfo === '-') verdeInfo = 'zona: ' + l.join(' > ');
    } catch (_) {}
  }
  setInterval(barrer, 1000);

  let p;
  function pintar() {
    if (!document.body) return;
    if (!p) {
      p = document.createElement('div');
      p.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483647;background:rgba(0,0,0,.6);color:#0f0;' +
        'font:10px monospace;padding:3px 5px;border-radius:4px;pointer-events:none;white-space:pre;max-width:60vw';
      document.body.appendChild(p);
    }
    p.textContent = 'mm' + cnt.mm + ' pm' + cnt.pm + ' md' + cnt.md + ' mu' + cnt.mu + ' lock' + cnt.pl + ' touch' + cnt.tc +
      '\n' + last + '\n' + verdeInfo + '\nlockEl:' + (document.pointerLockElement ? 'si' : 'no');
  }
  setInterval(pintar, 250);
})();
