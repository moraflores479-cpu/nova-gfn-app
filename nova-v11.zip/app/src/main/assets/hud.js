(() => {
  'use strict';
  // NOVA HUD v0.11: pildora con FPS / Hz y tarjeta con cambio de modo Teclado <-> Tactil.
  // F4 = mostrar / ocultar. Toca la pildora para abrir la tarjeta.
  const nat = window.NovaNative;
  const modo = window.__novaModo === 'tactil' ? 'tactil' : 'teclado';
  const LS = 'nova_hud';
  let visible = true;
  try { visible = localStorage.getItem(LS) !== 'off'; } catch (_) {}
  let abierto = false, pendiente = false;
  let fps = '-', hz = '-', perd = 0, calidad = '';

  // ---- medicion: FPS reales del video (cada 1 s) y Hz de la pantalla (rAF, solo si es visible) ----
  const raices = () => (window.__novaRaices ? window.__novaRaices() : [document]);
  const videoPrincipal = () => {
    let mejor = null, area = 0;
    for (const r of raices()) {
      let vs = []; try { vs = r.querySelectorAll('video'); } catch (_) {}
      for (const v of vs) {
        if (!v.videoWidth) continue;
        const a = v.videoWidth * v.videoHeight;
        if (a > area) { area = a; mejor = v; }
      }
    }
    return mejor;
  };
  let vPrev = null, fPrev = 0, dPrev = 0, tPrev = 0;
  function medirFps() {
    if (!visible) return;
    const v = videoPrincipal();
    if (!v || !v.getVideoPlaybackQuality) { fps = '-'; calidad = ''; return; }
    const q = v.getVideoPlaybackQuality(), t = performance.now();
    if (v === vPrev && t > tPrev) {
      const s = (t - tPrev) / 1000;
      fps = Math.max(0, Math.round((q.totalVideoFrames - fPrev) / s));
      perd = Math.max(0, Math.round((q.droppedVideoFrames - dPrev) / s));
    }
    vPrev = v; fPrev = q.totalVideoFrames; dPrev = q.droppedVideoFrames; tPrev = t;
    calidad = v.videoWidth + 'x' + v.videoHeight;
  }
  let rafOn = false, rn = 0, rt0 = 0;
  function frame(t) {
    if (!visible) { rafOn = false; return; }
    rn++; if (!rt0) rt0 = t;
    if (t - rt0 >= 1000) { hz = Math.round(rn * 1000 / (t - rt0)); rn = 0; rt0 = t; }
    requestAnimationFrame(frame);
  }

  // ---- interfaz (shadow DOM propio para que GeForce NOW no le cambie los estilos) ----
  let host, root, el = {};
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .wrap { position: fixed; top: 6px; left: 50%; transform: translateX(-50%); z-index: 2147483647;
      display: flex; flex-direction: column; align-items: center; gap: 6px; pointer-events: none; color: #e9edff; }
    .pill { pointer-events: auto; display: flex; align-items: center; gap: 8px; padding: 4px 11px; border-radius: 999px;
      background: rgba(14,17,28,.66); border: 1px solid rgba(255,255,255,.10); font-size: 12px; font-weight: 600;
      letter-spacing: .2px; opacity: .6; cursor: pointer; user-select: none; -webkit-user-select: none; white-space: nowrap; }
    .pill:active, .abierto .pill { opacity: 1; }
    .pill b { font-variant-numeric: tabular-nums; }
    .sep { width: 1px; height: 12px; background: rgba(255,255,255,.18); }
    .ok { color: #7ee0a6; } .med { color: #ffd166; } .mal { color: #ff6b6b; } .mut { color: #9aa4c7; }
    .card { pointer-events: auto; display: none; width: 268px; padding: 12px; border-radius: 16px;
      background: rgba(16,19,32,.94); border: 1px solid rgba(255,255,255,.10); box-shadow: 0 10px 30px rgba(0,0,0,.45); }
    .abierto .card { display: block; }
    .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .tit { font-size: 13px; font-weight: 700; } .tit small { font-weight: 500; color: #9aa4c7; margin-left: 4px; }
    .x { background: none; border: 0; color: #9aa4c7; font-size: 18px; line-height: 1; padding: 2px 6px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px; }
    .st { background: rgba(255,255,255,.05); border-radius: 12px; padding: 8px 10px; }
    .st span { display: block; font-size: 10px; text-transform: uppercase; letter-spacing: .6px; color: #9aa4c7; }
    .st strong { font-size: 20px; font-variant-numeric: tabular-nums; font-weight: 700; }
    .lbl { font-size: 10px; text-transform: uppercase; letter-spacing: .6px; color: #9aa4c7; margin: 0 0 6px 2px; }
    .seg { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; padding: 4px; background: rgba(255,255,255,.06); border-radius: 12px; }
    .seg button { border: 0; border-radius: 9px; padding: 9px 6px; font-size: 13px; font-weight: 600; color: #b9c2e6;
      background: transparent; }
    .seg button.on { background: #4f7cff; color: #fff; box-shadow: 0 2px 8px rgba(79,124,255,.45); }
    .aviso { margin-top: 10px; padding: 8px 10px; border-radius: 10px; background: rgba(255,209,102,.12); color: #ffd166;
      font-size: 12px; line-height: 1.35; display: none; }
    .aviso.v { display: block; }
    .aviso .fila { display: flex; gap: 6px; margin-top: 8px; }
    .aviso button { flex: 1; border: 0; border-radius: 8px; padding: 7px; font-size: 12px; font-weight: 700; }
    .si { background: #ffd166; color: #1b1500; } .no { background: rgba(255,255,255,.1); color: #e9edff; }
    .pie { margin-top: 10px; font-size: 10.5px; color: #7f89ad; line-height: 1.4; }
  `;
  const h = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

  function construir() {
    host = document.createElement('div');
    root = host.attachShadow({ mode: 'closed' });
    const st = document.createElement('style'); st.textContent = CSS; root.appendChild(st);
    const wrap = h('div', 'wrap'); el.wrap = wrap;

    const pill = h('div', 'pill'); el.pill = pill;
    el.pFps = h('b', '', '-'); el.pHz = h('b', '', '-'); el.pModo = h('span', '', '');
    pill.append(el.pFps, h('span', 'mut', 'FPS'), h('span', 'sep'), el.pHz, h('span', 'mut', 'Hz'), h('span', 'sep'), el.pModo);

    const card = h('div', 'card');
    const top = h('div', 'top');
    const tit = h('div', 'tit', 'NOVA GFN'); tit.appendChild(h('small', '', 'v0.11'));
    const x = h('button', 'x', '×'); x.setAttribute('aria-label', 'Cerrar');
    top.append(tit, x);
    const grid = h('div', 'grid');
    const mk = (k, etiqueta) => { const d = h('div', 'st'); d.append(h('span', '', etiqueta)); el[k] = h('strong', '', '-'); d.append(el[k]); return d; };
    grid.append(mk('cFps', 'FPS del stream'), mk('cHz', 'Pantalla (Hz)'), mk('cPerd', 'Cuadros perdidos/s'), mk('cRes', 'Resolución'));
    const lbl = h('p', 'lbl', 'Modo de control');
    const seg = h('div', 'seg');
    el.bTec = h('button', '', '⌨  Teclado'); el.bTac = h('button', '', '☝  Táctil');
    seg.append(el.bTec, el.bTac);
    const av = h('div', 'aviso'); el.av = av;
    el.avTxt = h('div', '', '');
    const fila = h('div', 'fila'); el.bSi = h('button', 'si', 'Cambiar'); el.bNo = h('button', 'no', 'Cancelar');
    fila.append(el.bSi, el.bNo); av.append(el.avTxt, fila);
    const pie = h('div', 'pie', 'F4 oculta este panel · F8 captura o suelta el mouse · F3 sincroniza el cursor');
    card.append(top, grid, lbl, seg, av, pie);

    wrap.append(pill, card); root.appendChild(wrap);

    // que lo tocado aqui no llegue al juego
    ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'touchstart', 'touchend', 'touchmove', 'wheel', 'contextmenu']
      .forEach((t) => wrap.addEventListener(t, (e) => e.stopPropagation()));
    pill.addEventListener('click', () => { abierto = !abierto; pendiente = false; pintar(); });
    x.addEventListener('click', () => { abierto = false; pendiente = false; pintar(); });
    el.bTec.addEventListener('click', () => pedir('teclado'));
    el.bTac.addEventListener('click', () => pedir('tactil'));
    el.bNo.addEventListener('click', () => { pendiente = false; pintar(); });
    el.bSi.addEventListener('click', () => {
      const nuevo = modo === 'teclado' ? 'tactil' : 'teclado';
      el.avTxt.textContent = 'Cambiando de modo…'; el.bSi.disabled = true; el.bNo.disabled = true;
      try { nat.setModo(nuevo); } catch (_) { el.avTxt.textContent = 'No se pudo cambiar (falta el puente nativo).'; }
    });
  }

  function pedir(m) {
    if (m === modo) return;
    pendiente = true;
    el.avTxt.textContent = m === 'tactil'
      ? 'Pasar a Táctil recarga la página y se reinicia el stream. Podrías tener que volver a entrar a la partida.'
      : 'Pasar a Teclado recarga la página y se reinicia el stream. Podrías tener que volver a entrar a la partida.';
    pintar();
  }

  const clase = (n) => (n === '-' ? 'mut' : n >= 55 ? 'ok' : n >= 30 ? 'med' : 'mal');
  function pintar() {
    if (!host) return;
    el.wrap.className = 'wrap' + (abierto ? ' abierto' : '');
    el.pFps.textContent = fps; el.pFps.className = clase(fps);
    el.pHz.textContent = hz; el.pHz.className = hz === '-' ? 'mut' : '';
    el.pModo.textContent = modo === 'tactil' ? '☝' : '⌨';
    if (!abierto) return;
    el.cFps.textContent = fps; el.cFps.className = clase(fps);
    el.cHz.textContent = hz;
    el.cPerd.textContent = perd; el.cPerd.className = perd === 0 ? 'ok' : perd < 5 ? 'med' : 'mal';
    el.cRes.textContent = calidad || '-';
    el.cRes.style.fontSize = '15px';
    el.bTec.className = modo === 'teclado' ? 'on' : '';
    el.bTac.className = modo === 'tactil' ? 'on' : '';
    el.av.className = 'aviso' + (pendiente ? ' v' : '');
  }

  function montar() {
    if (!visible) { if (host && host.parentNode) host.remove(); return; }
    if (!host) construir();
    if (!host.isConnected && document.documentElement) document.documentElement.appendChild(host);
    if (!rafOn) { rafOn = true; rn = 0; rt0 = 0; requestAnimationFrame(frame); }
    pintar();
  }

  window.addEventListener('keydown', (e) => {
    if (e.code === 'F4') {
      visible = !visible;
      try { localStorage.setItem(LS, visible ? 'on' : 'off'); } catch (_) {}
      montar(); e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'Escape' && abierto) {
      abierto = false; pendiente = false; pintar();
    }
  }, true);

  setInterval(() => { medirFps(); montar(); }, 1000);
  document.addEventListener('DOMContentLoaded', montar);
  window.__novaHud = () => ({ fps, hz, perd, modo });
})();
