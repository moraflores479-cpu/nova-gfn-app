// ==UserScript==
// @name         NOVA PC Mode for GeForce NOW
// @namespace    nova-cloud
// @version      0.1.0
// @description  Hace que la pagina de GeForce NOW vea el navegador como equipo de escritorio sin pantalla tactil. Prueba, sin garantias.
// @match        https://play.geforcenow.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  'use strict';
  if (window.__novaModo === 'tactil') return; // modo tactil: no se simula PC ni se captura el mouse

  // ───────── CONFIGURACIÓN ─────────
  const CONFIG = {
    ocultarTactil: true,      // maxTouchPoints = 0 y pointer "fine" (como si hubiera mouse)
    plataformaWindows: true,  // navigator.platform = 'Win32'
    cambiarUserAgent: false,  // true = tambien cambia el User-Agent a Windows/Firefox (normalmente basta "Sitio para computadoras")
    mostrarAviso: true,
  };
  // ──────────────────────────────────

  const definir = (obj, prop, valor) => {
    try {
      Object.defineProperty(obj, prop, { get: () => valor, configurable: true });
    } catch (_) {}
  };

  if (CONFIG.ocultarTactil) {
    definir(Navigator.prototype, 'maxTouchPoints', 0);

    // matchMedia: "(pointer: coarse)" -> falso, "(pointer: fine)" / "(hover: hover)" -> verdadero
    const mm = window.matchMedia.bind(window);
    window.matchMedia = (q) => {
      const r = mm(q);
      const s = String(q).replace(/\s+/g, '');
      let forzar = null;
      if (/\(pointer:coarse\)|\(any-pointer:coarse\)/.test(s)) forzar = false;
      else if (/\(pointer:fine\)|\(any-pointer:fine\)|\(hover:hover\)|\(any-hover:hover\)/.test(s)) forzar = true;
      if (forzar === null) return r;
      return new Proxy(r, {
        get(t, k) {
          if (k === 'matches') return forzar;
          const v = t[k];
          return typeof v === 'function' ? v.bind(t) : v;
        },
      });
    };
  }

  if (CONFIG.plataformaWindows) {
    definir(Navigator.prototype, 'platform', 'Win32');
  }

  if (CONFIG.cambiarUserAgent) {
    const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0';
    definir(Navigator.prototype, 'userAgent', ua);
    definir(Navigator.prototype, 'appVersion', '5.0 (Windows)');
  }

  if (CONFIG.mostrarAviso) {
    window.addEventListener('DOMContentLoaded', () => {
      const d = document.createElement('div');
      d.textContent = 'NOVA PC Mode activo';
      d.style.cssText = 'position:fixed;bottom:8px;left:8px;z-index:2147483647;background:rgba(0,0,0,.7);' +
        'color:#fff;font:12px sans-serif;padding:5px 9px;border-radius:6px;pointer-events:none';
      document.body.appendChild(d);
      setTimeout(() => d.remove(), 3000);
    });
  }
})();
