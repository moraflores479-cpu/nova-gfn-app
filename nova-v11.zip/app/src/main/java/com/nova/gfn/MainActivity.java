package com.nova.gfn;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private WebView web;
    private String js = "";
    private String modo = "teclado"; // "teclado" (PC: mouse y teclado) o "tactil"
    private ScriptHandler scriptHandler;
    private static final String HOME = "https://play.geforcenow.com/";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    // ---- Captura de mouse (estilo maquina virtual) ----
    private final Handler h = new Handler(Looper.getMainLooper());
    private float adx, ady, asx, asy;      // movimiento / scroll acumulado
    private int curMask = 0, sentMask = 0; // botones (mismos bits que MouseEvent.buttons)
    private boolean flushPend = false;
    private final Runnable flusher = new Runnable() { @Override public void run() { flush(); } };

    private String leer(String f) {
        try (InputStream in = getAssets().open(f)) {
            byte[] b = new byte[in.available()]; in.read(b); return new String(b, "UTF-8") + "\n";
        } catch (Exception e) { return ""; }
    }

    /** Lo llama el JS (capture.js) para pedir / soltar la captura del mouse. */
    public class Bridge {
        @JavascriptInterface public void setModo(final String m) {
            final String nuevo = "tactil".equals(m) ? "tactil" : "teclado";
            runOnUiThread(new Runnable() { @Override public void run() { cambiarModo(nuevo); } });
        }
        @JavascriptInterface public String modo() { return modo; }
            @JavascriptInterface public void capture(final boolean on) {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (on) { web.requestFocus(); web.requestPointerCapture(); }
                else web.releasePointerCapture();
            } });
        }
    }

    private int nEv = 0, lastAct = -1, lastSrc = 0;
    private boolean usoRel = false;

    private void addMove(MotionEvent ev) {
        boolean relSrc = (ev.getSource() & android.view.InputDevice.SOURCE_MOUSE_RELATIVE) == android.view.InputDevice.SOURCE_MOUSE_RELATIVE;
        int n = ev.getHistorySize();
        for (int i = 0; i <= n; i++) {
            float rx, ry, gx, gy;
            if (i < n) {
                rx = ev.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_X, i); ry = ev.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_Y, i);
                gx = ev.getHistoricalX(i); gy = ev.getHistoricalY(i);
            } else {
                rx = ev.getAxisValue(MotionEvent.AXIS_RELATIVE_X); ry = ev.getAxisValue(MotionEvent.AXIS_RELATIVE_Y);
                gx = ev.getX(); gy = ev.getY();
            }
            if (rx != 0 || ry != 0) { adx += rx; ady += ry; usoRel = true; }
            else if (relSrc) { adx += gx; ady += gy; usoRel = false; }
        }
    }

    private String construirJs(String m) {
        return "window.__novaModo='" + m + "';\n" + leer("pcmode.js") + leer("movefix.js") + leer("capture.js")
            + leer("fit.js") + leer("hud.js") + leer("diag.js");
    }

    /** Desktop (Windows) para teclado y mouse; Chrome movil para tactil. */
    private String uaPara(String m) {
        if ("tactil".equals(m)) return WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        return UA;
    }

    private void cambiarModo(String nuevo) {
        if (nuevo.equals(modo)) return;
        modo = nuevo;
        getSharedPreferences("nova", MODE_PRIVATE).edit().putString("modo", nuevo).apply();
        web.releasePointerCapture();
        js = construirJs(modo);
        web.getSettings().setUserAgentString(uaPara(modo));
        if (scriptHandler != null) { scriptHandler.remove(); scriptHandler = null; }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
        web.loadUrl(HOME);
    }

    private void captured(MotionEvent ev) {
        nEv++; lastAct = ev.getActionMasked(); lastSrc = ev.getSource();
        addMove(ev);
        if (ev.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            asx += ev.getAxisValue(MotionEvent.AXIS_HSCROLL);
            asy += ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
        }
        int b = ev.getButtonState();
        if (b != curMask) { curMask = b; flush(); return; } // cambio de boton: se manda ya, sin juntar
        if (!flushPend) { flushPend = true; h.postDelayed(flusher, 8); }
    }

    private void flush() {
        flushPend = false; h.removeCallbacks(flusher);
        if (adx == 0 && ady == 0 && asx == 0 && asy == 0 && curMask == sentMask) return;
        String dbg = "n" + nEv + " a" + lastAct + " s" + Integer.toHexString(lastSrc) + (usoRel ? " rel" : " xy");
        String s = "window.__novaIn&&window.__novaIn(" + adx + "," + ady + "," + curMask + "," + asx + "," + asy + ",'" + dbg + "')";
        adx = ady = asx = asy = 0; sentMask = curMask;
        web.evaluateJavascript(s, null);
    }

    @Override public void onPointerCaptureChanged(boolean has) {
        super.onPointerCaptureChanged(has);
        if (!has) { adx = ady = asx = asy = 0; curMask = 0; sentMask = 0; }
        if (web != null) web.evaluateJavascript("window.__novaCap&&window.__novaCap(" + has + ")", null);
    }

    /** Pide la tasa de refresco mas alta de la pantalla (p. ej. 120 Hz) en vez de quedarse en 60. */
    private void pedirMaxRefresco() {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode mejor = null;
            for (Display.Mode m : d.getSupportedModes()) {
                if (mejor == null || m.getRefreshRate() > mejor.getRefreshRate()) mejor = m;
            }
            if (mejor == null) return;
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredRefreshRate = mejor.getRefreshRate();
            lp.preferredDisplayModeId = mejor.getModeId();
            getWindow().setAttributes(lp);
        } catch (Exception ignored) { }
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        modo = getSharedPreferences("nova", MODE_PRIVATE).getString("modo", "teclado");
        js = construirJs(modo);
        pedirMaxRefresco();
        web = new WebView(this);
        setContentView(web);
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        web.addJavascriptInterface(new Bridge(), "NovaNative");
        web.setOnCapturedPointerListener(new View.OnCapturedPointerListener() {
            @Override public boolean onCapturedPointer(View v, MotionEvent ev) { captured(ev); return true; }
        });
        WebSettings st = web.getSettings();
        st.setSafeBrowsingEnabled(false);
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setUserAgentString(uaPara(modo));
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);
        web.setWebChromeClient(new WebChromeClient());
        boolean doc = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (doc) scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap b) {
                if (!doc && url != null && url.contains("geforcenow.com")) v.evaluateJavascript(js, null);
            }
        });
        web.loadUrl(HOME);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
