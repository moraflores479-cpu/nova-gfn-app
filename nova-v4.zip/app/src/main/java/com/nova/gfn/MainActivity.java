package com.nova.gfn;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private WebView web;
    private String js = "";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    // ---- Captura de mouse (estilo maquina virtual) ----
    private final Handler h = new Handler(Looper.getMainLooper());
    private float adx, ady, asx, asy;      // movimiento / scroll acumulado
    private int curMask = 0, sentMask = 0; // botones (mismos bits que MouseEvent.buttons)
    private boolean flushPend = false;
    private final Runnable flusher = new Runnable() { @Override public void run() { flush(); } };

    private String leer(String f) {
        try (InputStream in = getAssets().open(f)) {
            byte[] b = new byte[in.available()]; in.read(b); return new String(b, "UTF-8") + "\n";
        } catch (Exception e) { return ""; }
    }

    /** Lo llama el JS (capture.js) para pedir / soltar la captura del mouse. */
    public class Bridge {
        @JavascriptInterface public void capture(final boolean on) {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (on) { web.requestFocus(); web.requestPointerCapture(); }
                else web.releasePointerCapture();
            } });
        }
    }

    private void captured(MotionEvent ev) {
        int n = ev.getHistorySize();
        for (int i = 0; i < n; i++) { adx += ev.getHistoricalX(i); ady += ev.getHistoricalY(i); }
        adx += ev.getX(); ady += ev.getY();
        if (ev.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            asx += ev.getAxisValue(MotionEvent.AXIS_HSCROLL);
            asy += ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
        }
        int b = ev.getButtonState();
        if (b != curMask) { curMask = b; flush(); return; } // cambio de boton: se manda ya, sin juntar
        if (!flushPend) { flushPend = true; h.postDelayed(flusher, 4); }
    }

    private void flush() {
        flushPend = false; h.removeCallbacks(flusher);
        if (adx == 0 && ady == 0 && asx == 0 && asy == 0 && curMask == sentMask) return;
        String s = "window.__novaIn&&window.__novaIn(" + adx + "," + ady + "," + curMask + "," + asx + "," + asy + ")";
        adx = ady = asx = asy = 0; sentMask = curMask;
        web.evaluateJavascript(s, null);
    }

    @Override public void onPointerCaptureChanged(boolean has) {
        super.onPointerCaptureChanged(has);
        if (!has) { adx = ady = asx = asy = 0; curMask = 0; sentMask = 0; }
        if (web != null) web.evaluateJavascript("window.__novaCap&&window.__novaCap(" + has + ")", null);
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        js = leer("pcmode.js") + leer("movefix.js") + leer("capture.js") + leer("fit.js") + leer("diag.js");
        web = new WebView(this);
        setContentView(web);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        web.addJavascriptInterface(new Bridge(), "NovaNative");
        web.setOnCapturedPointerListener(new View.OnCapturedPointerListener() {
            @Override public boolean onCapturedPointer(View v, MotionEvent ev) { captured(ev); return true; }
        });
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setUserAgentString(UA);
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);
        web.setWebChromeClient(new WebChromeClient());
        boolean doc = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (doc) WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap b) {
                if (!doc && url != null && url.contains("geforcenow.com")) v.evaluateJavascript(js, null);
            }
        });
        web.loadUrl("https://play.geforcenow.com/");
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
