(() => {
  'use strict';
  // NOVA HUD v0.12: pildora con FPS / Hz y tarjeta con rendimiento real (codec, decodificador),
  // modo de control, modo del mouse (camara / menu), refresco de pantalla y codec.
  // F4 = mostrar / ocultar. Toca la pildora para abrir la tarjeta.
  const nat = window.NovaNative;
  let modo = (window.__novaModo === 'tactil' || window.__novaModo === 'movil') ? window.__novaModo : 'teclado';
  let pendM = null; // modo que espera confirmacion (solo cuando implica recargar)
  const LS = 'nova_hud';
  let visible = true;
  try { visible = localStorage.getItem(LS) !== 'off'; } catch (_) {}
  let abierto = false, pendiente = false, notaCodec = false;
  let fps = '-', hz = '-', perd = 0, calidad = '', cajaVideo = '';
  let st = null, decMs = '-', stPrev = null;

  // ---- medicion: FPS reales del video (cada 1 s) y Hz de la pantalla (rAF, solo si es visible) ----
  const raices = () => (window.__novaRaices ? window.__novaRaices() : [document]);
  const videoPrincipal = () => {
    let mejor = null, area = 0;
    for (const r of raices()) {
      let vs = []; try { vs = r.querySelectorAll('video'); } catch (_) {}
      for (const v of vs) {
        if (!v.videoWidth) continue;
        const a = v.videoWidth * v.videoHeight;
        if (a > area) { area = a; mejor = v; }
      }
    }
    return mejor;
  };
  let vPrev = null, fPrev = 0, dPrev = 0, tPrev = 0;
  function medirFps() {
    if (!visible) return;
    const v = videoPrincipal();
    if (!v || !v.getVideoPlaybackQuality) { fps = '-'; calidad = ''; cajaVideo = ''; return; }
    const q = v.getVideoPlaybackQuality(), t = performance.now();
    if (v === vPrev && t > tPrev) {
      const s = (t - tPrev) / 1000;
      fps = Math.max(0, Math.round((q.totalVideoFrames - fPrev) / s));
      perd = Math.max(0, Math.round((q.droppedVideoFrames - dPrev) / s));
    }
    vPrev = v; fPrev = q.totalVideoFrames; dPrev = q.droppedVideoFrames; tPrev = t;
    calidad = v.videoWidth + '×' + v.videoHeight;
    if (abierto) {
      const r = v.getBoundingClientRect();
      cajaVideo = 'caja ' + Math.round(r.width) + '×' + Math.round(r.height) + ' @' + Math.round(r.left) + ',' + Math.round(r.top) +
        ' · ventana ' + innerWidth + '×' + innerHeight;
    }
  }
  async function medirStats() {
    if (!visible || !abierto || !window.__novaStats) return;
    try {
      const s = await window.__novaStats();
      if (!s) { st = null; decMs = '-'; return; }
      if (stPrev && s.decoded > stPrev.decoded && s.totalDecode != null && stPrev.totalDecode != null) {
        decMs = (((s.totalDecode - stPrev.totalDecode) / (s.decoded - stPrev.decoded)) * 1000).toFixed(1);
      }
      stPrev = s; st = s;
    } catch (_) {}
  }
  let rafOn = false, rn = 0, rt0 = 0;
  function frame(t) {
    if (!visible) { rafOn = false; return; }
    rn++; if (!rt0) rt0 = t;
    if (t - rt0 >= 1000) { hz = Math.round(rn * 1000 / (t - rt0)); rn = 0; rt0 = t; }
    requestAnimationFrame(frame);
  }

  // ---- interfaz (shadow DOM propio para que GeForce NOW no le cambie los estilos) ----
  let host, root, el = {};
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .wrap { position: fixed; top: 6px; left: 50%; transform: translateX(-50%); z-index: 2147483647;
      display: flex; flex-direction: column; align-items: center; gap: 6px; pointer-events: none; color: #e9edff;
      max-width: 96vw; }
    .pill { pointer-events: auto; display: flex; align-items: center; gap: 8px; padding: 4px 11px; border-radius: 999px;
      background: rgba(14,17,28,.66); border: 1px solid rgba(255,255,255,.10); font-size: 12px; font-weight: 600;
      letter-spacing: .2px; opacity: .6; cursor: pointer; user-select: none; -webkit-user-select: none; white-space: nowrap; }
    .pill:active, .abierto .pill { opacity: 1; }
    .pill b { font-variant-numeric: tabular-nums; }
    .sep { width: 1px; height: 12px; background: rgba(255,255,255,.18); }
    .ok { color: #7ee0a6; } .med { color: #ffd166; } .mal { color: #ff6b6b; } .mut { color: #9aa4c7; }
    .card { pointer-events: auto; display: none; width: min(600px, 96vw); max-height: calc(100vh - 44px); overflow-y: auto;
      padding: 12px; border-radius: 16px; background: rgba(16,19,32,.95); border: 1px solid rgba(255,255,255,.10);
      box-shadow: 0 10px 30px rgba(0,0,0,.45); }
    .abierto .card { display: block; }
    .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .tit { font-size: 13px; font-weight: 700; } .tit small { font-weight: 500; color: #9aa4c7; margin-left: 4px; }
    .x { background: none; border: 0; color: #9aa4c7; font-size: 20px; line-height: 1; padding: 2px 8px; }
    .cols { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 520px) { .cols { grid-template-columns: 1fr; } }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; align-content: start; }
    .t { background: rgba(255,255,255,.05); border-radius: 11px; padding: 6px 9px; min-width: 0; }
    .t span { display: block; font-size: 9.5px; text-transform: uppercase; letter-spacing: .5px; color: #9aa4c7; }
    .t strong { font-size: 17px; font-variant-numeric: tabular-nums; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
    .t.w { grid-column: span 2; } .t.w strong { font-size: 13px; }
    .lbl { font-size: 9.5px; text-transform: uppercase; letter-spacing: .5px; color: #9aa4c7; margin: 8px 0 4px 2px; }
    .lbl:first-child { margin-top: 0; }
    .seg { display: flex; gap: 3px; padding: 3px; background: rgba(255,255,255,.06); border-radius: 11px; }
    .seg button { flex: 1; border: 0; border-radius: 8px; padding: 8px 4px; font-size: 12.5px; font-weight: 600; color: #b9c2e6; background: transparent; }
    .seg button.on { background: #4f7cff; color: #fff; box-shadow: 0 2px 8px rgba(79,124,255,.45); }
    .aviso { margin-top: 8px; padding: 8px 10px; border-radius: 10px; background: rgba(255,209,102,.12); color: #ffd166;
      font-size: 11.5px; line-height: 1.35; display: none; }
    .aviso.v { display: block; }
    .aviso .fila { display: flex; gap: 6px; margin-top: 8px; }
    .aviso button { flex: 1; border: 0; border-radius: 8px; padding: 7px; font-size: 12px; font-weight: 700; }
    .si { background: #ffd166; color: #1b1500; } .no { background: rgba(255,255,255,.1); color: #e9edff; }
    .hint { margin: 5px 2px 8px; font-size: 10.5px; color: #8a94b8; line-height: 1.3; }
    .nota { margin-top: 6px; font-size: 11px; color: #ffd166; display: none; } .nota.v { display: block; }
    .pie { margin-top: 10px; font-size: 10px; color: #7f89ad; line-height: 1.4; }
  `;
  const h = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

  // fila de botones tipo segmento; opciones = [[valor, etiqueta], ...]
  function seg(opciones, alElegir) {
    const cont = h('div', 'seg'), bs = {};
    opciones.forEach(([v, et]) => { const b = h('button', '', et); b.addEventListener('click', () => alElegir(v)); cont.appendChild(b); bs[v] = b; });
    return { cont, marca(v) { for (const k in bs) bs[k].className = String(k) === String(v) ? 'on' : ''; } };
  }

  function construir() {
    host = document.createElement('div');
    root = host.attachShadow({ mode: 'closed' });
    const sty = document.createElement('style'); sty.textContent = CSS; root.appendChild(sty);
    const wrap = h('div', 'wrap'); el.wrap = wrap;

    const pill = h('div', 'pill');
    el.pFps = h('b', '', '-'); el.pHz = h('b', '', '-'); el.pModo = h('span', '', '');
    pill.append(el.pFps, h('span', 'mut', 'FPS'), h('span', 'sep'), el.pHz, h('span', 'mut', 'Hz'), h('span', 'sep'), el.pModo);

    const card = h('div', 'card');
    const top = h('div', 'top');
    const tit = h('div', 'tit', 'NOVA GFN'); tit.appendChild(h('small', '', 'v0.13'));
    const x = h('button', 'x', '×'); x.setAttribute('aria-label', 'Cerrar');
    top.append(tit, x);

    // columna izquierda: rendimiento
    const izq = h('div', ''); izq.append(h('p', 'lbl', 'Rendimiento'));
    const grid = h('div', 'grid');
    const mk = (k, etiqueta, ancho) => { const d = h('div', 't' + (ancho ? ' w' : '')); d.append(h('span', '', etiqueta)); el[k] = h('strong', '', '-'); d.append(el[k]); return d; };
    grid.append(mk('cFps', 'FPS del stream'), mk('cHz', 'Pantalla (Hz)'), mk('cPerd', 'Perdidos/s'), mk('cDec', 'Decodifica (ms)'),
      mk('cCod', 'Códec · decodificador', true), mk('cRes', 'Resolución del stream', true));
    izq.append(grid);

    // columna derecha: ajustes
    const der = h('div', '');
    der.append(h('p', 'lbl', 'Modo de control'));
    el.sCtl = seg([['teclado', '⌨ Teclado'], ['tactil', '☝ Táctil'], ['movil', '📱 Móvil']], (m) => pedir(m)); der.append(el.sCtl.cont);
    el.hint = h('div', 'hint', ''); der.append(el.hint);
    el.filaMouse = h('div', '');
    el.filaMouse.append(h('p', 'lbl', 'Mouse  (F8)'));
    el.sMouse = seg([['camara', '🎯 Cámara'], ['menu', '🖱 Menú']], () => { if (window.__novaToggleMouse) window.__novaToggleMouse(); });
    el.filaMouse.append(el.sMouse.cont); der.append(el.filaMouse);
    der.append(h('p', 'lbl', 'Refresco de pantalla'));
    const refs = String(window.__novaRefrescos || '60,120').split(',').filter(Boolean).map((n) => [n, n + ' Hz']);
    el.sHz = seg(refs, (v) => { try { nat.setRefresco(+v); } catch (_) {} window.__novaRefresco = +v; pintar(); });
    der.append(el.sHz.cont);
    der.append(h('p', 'lbl', 'Códec de video'));
    el.sCod = seg([['auto', 'Auto'], ['h264', 'H.264'], ['todo', 'Todos']], (v) => {
      if (window.__novaSetCodec) window.__novaSetCodec(v);
      notaCodec = true; pintar();
    });
    der.append(el.sCod.cont);
    el.nota = h('div', 'nota', 'El códec se aplica al reiniciar el stream: sal de la partida y vuelve a entrar.');
    der.append(el.nota);

    const av = h('div', 'aviso'); el.av = av;
    el.avTxt = h('div', '', '');
    const fila = h('div', 'fila'); el.bSi = h('button', 'si', 'Cambiar'); el.bNo = h('button', 'no', 'Cancelar');
    fila.append(el.bSi, el.bNo); av.append(el.avTxt, fila);

    const cols = h('div', 'cols'); cols.append(izq, der);
    el.pie = h('div', 'pie', '');
    card.append(top, cols, av, el.pie);

    wrap.append(pill, card); root.appendChild(wrap);

    // que lo tocado aqui no llegue al juego
    ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'touchstart', 'touchend', 'touchmove', 'wheel', 'contextmenu']
      .forEach((t) => wrap.addEventListener(t, (e) => e.stopPropagation()));
    pill.addEventListener('click', () => { abierto = !abierto; pendiente = false; pintar(); if (abierto) { medirFps(); medirStats(); } });
    x.addEventListener('click', () => { abierto = false; pendiente = false; pintar(); });
    el.bNo.addEventListener('click', () => { pendiente = false; pintar(); });
    el.bSi.addEventListener('click', () => {
      el.avTxt.textContent = 'Cambiando de modo…'; el.bSi.disabled = true; el.bNo.disabled = true;
      try { nat.setModo(pendM); } catch (_) { el.avTxt.textContent = 'No se pudo cambiar (falta el puente nativo).'; }
    });
  }

  const HINTS = {
    teclado: 'PC · mouse capturado para la cámara (F8 lo suelta para los menús).',
    tactil: 'PC · toca la pantalla y el mouse es un puntero normal. Sigues viendo los ajustes gráficos de PC.',
    movil: 'Celular real: controles táctiles de GeForce NOW, pero puede ocultar ajustes gráficos (mallas, etc.).',
  };
  function pedir(m) {
    if (m === modo) return;
    if (m === 'movil' || modo === 'movil') { // cambia la identidad del navegador: hay que recargar
      pendiente = true; pendM = m;
      el.avTxt.textContent = (m === 'movil' ? 'Pasar a Móvil' : 'Volver a PC') +
        ' recarga la página y se reinicia el stream. Podrías tener que volver a entrar a la partida.';
      pintar(); return;
    }
    // Teclado <-> Táctil: misma identidad de PC, se cambia al instante sin recargar
    modo = m; window.__novaModo = m; pendiente = false;
    try { nat.setModo(m); } catch (_) {}
    pintar();
  }

  const clase = (n) => (n === '-' ? 'mut' : n >= 55 ? 'ok' : n >= 30 ? 'med' : 'mal');
  function pintar() {
    if (!host) return;
    el.wrap.className = 'wrap' + (abierto ? ' abierto' : '');
    el.pFps.textContent = fps; el.pFps.className = clase(fps);
    el.pHz.textContent = hz; el.pHz.className = hz === '-' ? 'mut' : '';
    const lk = window.__novaLocked && window.__novaLocked();
    el.pModo.textContent = modo === 'tactil' ? '☝' : modo === 'movil' ? '📱' : (lk ? '🎯' : '🖱');
    if (!abierto) return;
    el.cFps.textContent = fps; el.cFps.className = clase(fps);
    el.cHz.textContent = hz; el.cHz.className = hz === '-' ? 'mut' : '';
    el.cPerd.textContent = perd; el.cPerd.className = perd === 0 ? 'ok' : perd < 5 ? 'med' : 'mal';
    const dn = parseFloat(decMs);
    el.cDec.textContent = decMs; el.cDec.className = isNaN(dn) ? 'mut' : dn < 8 ? 'ok' : dn < 16 ? 'med' : 'mal';
    el.cCod.textContent = st ? st.codec + ' · ' + st.decoder : '-';
    el.cRes.textContent = calidad || '-';
    el.sCtl.marca(modo);
    el.sMouse.marca(lk ? 'camara' : 'menu');
    el.filaMouse.style.display = modo === 'teclado' ? '' : 'none';
    el.hint.textContent = HINTS[modo];
    el.sHz.marca(window.__novaRefresco || 60);
    el.sCod.marca(window.__novaCodec ? window.__novaCodec() : 'auto');
    el.nota.className = 'nota' + (notaCodec ? ' v' : '');
    el.av.className = 'aviso' + (pendiente ? ' v' : '');
    el.pie.textContent = (cajaVideo ? cajaVideo + '\n' : '') + 'F4 oculta este panel · F8 cámara/menú · F3 sincroniza el cursor · F1 diagnóstico';
    el.pie.style.whiteSpace = 'pre-line';
  }

  function montar() {
    if (!visible) { if (host && host.parentNode) host.remove(); return; }
    if (!host) construir();
    if (!host.isConnected && document.documentElement) document.documentElement.appendChild(host);
    if (!rafOn) { rafOn = true; rn = 0; rt0 = 0; requestAnimationFrame(frame); }
    pintar();
  }

  window.addEventListener('keydown', (e) => {
    if (e.code === 'F4') {
      visible = !visible;
      try { localStorage.setItem(LS, visible ? 'on' : 'off'); } catch (_) {}
      montar(); e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'Escape' && abierto) {
      abierto = false; pendiente = false; pintar();
    }
  }, true);
  document.addEventListener('pointerlockchange', () => pintar());

  setInterval(() => { medirFps(); montar(); }, 1000);
  setInterval(medirStats, 2000);
  document.addEventListener('DOMContentLoaded', montar);
  window.__novaHud = () => ({ fps, hz, perd, modo, decMs, stats: st });
})();
