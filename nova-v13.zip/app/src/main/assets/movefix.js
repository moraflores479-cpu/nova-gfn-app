(() => {
  'use strict';
  if (window.__novaModo === 'movil') return; // celular real
  // NOVA MoveFix: en WebView el mouse OTG manda posicion pero movementX/Y = 0.
  // Calculamos el movimiento nosotros y lo exponemos en movementX/movementY.
  const LS = 'nova_mv_factor';
  let factor = 1.5;
  try { const g = parseFloat(localStorage.getItem(LS)); if (g > 0) factor = g; } catch (_) {}
  window.__novaMvFactor = () => factor;

  const dX = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'movementX');
  const dY = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'movementY');
  if (!dX || !dY || !dX.get || !dY.get) return;

  const calc = new WeakMap();
  const last = {}; // por tipo: mousemove / pointermove
  let resto = { x: 0, y: 0 };

  const MOVES = ['mousemove', 'pointermove', 'pointerrawupdate'];
  MOVES.forEach((t) => window.addEventListener(t, (e) => {
    if (e.pointerType && e.pointerType !== 'mouse') return;
    const ox = dX.get.call(e), oy = dY.get.call(e);
    const p = last[t];
    last[t] = { x: e.clientX, y: e.clientY, t: e.timeStamp };
    if ((ox !== 0 || oy !== 0) || !p) return;           // ya trae movimiento real, o primer evento
    if (e.timeStamp - p.t > 300) return;                 // salto largo: no inventar movimiento
    const fx = (e.clientX - p.x) * factor + resto.x;
    const fy = (e.clientY - p.y) * factor + resto.y;
    const rx = Math.round(fx), ry = Math.round(fy);
    resto = { x: fx - rx, y: fy - ry };
    calc.set(e, { x: rx, y: ry });
  }, true));

  Object.defineProperty(MouseEvent.prototype, 'movementX', {
    get() { const c = calc.get(this); return c ? c.x : dX.get.call(this); }, configurable: true,
  });
  Object.defineProperty(MouseEvent.prototype, 'movementY', {
    get() { const c = calc.get(this); return c ? c.y : dY.get.call(this); }, configurable: true,
  });

  // F9 = mas lento, F10 = mas rapido
  window.addEventListener('keydown', (e) => {
    if (e.code !== 'F9' && e.code !== 'F10') return;
    if (window.__novaLocked && window.__novaLocked()) return; // capturado: lo maneja capture.js
    factor = Math.min(4, Math.max(0.2, Math.round((factor + (e.code === 'F10' ? 0.1 : -0.1)) * 10) / 10));
    try { localStorage.setItem(LS, String(factor)); } catch (_) {}
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);
})();
