(() => {
  'use strict';
  // NOVA v0.12: ocultador del aviso verde "Ctrl+G" (por observador, sin escaneos periodicos) + panel de diagnostico (F1).
  const cnt = { mm: 0, pm: 0, md: 0, mu: 0, pl: 0, tc: 0 };
  let last = '-', verdeInfo = '-';
  const LSP = 'nova_panel_visible', LSV = 'nova_hide_green';
  let verPanel = false, ocultarVerde = true;
  try { verPanel = localStorage.getItem(LSP) === '1'; ocultarVerde = localStorage.getItem(LSV) !== '0'; } catch (_) {}
  const sombras = new Set();

  const nombre = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
    (typeof e.className === 'string' && e.className ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
  const esVerde = (c) => {
    const m = String(c).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
    return !!m && (m[4] === undefined || +m[4] > 0.3) && Math.abs(m[1] - 118) < 35 && Math.abs(m[2] - 185) < 35 && m[3] < 60;
  };
  const raices = () => [document, ...sombras];
  window.__novaRaices = raices;
  const hayStream = () => {
    for (const r of raices()) {
      let vs = []; try { vs = r.querySelectorAll('video'); } catch (_) {}
      for (const v of vs) if (v.videoWidth > 0 && !v.paused) return true;
    }
    return false;
  };
  const oculta = (e) => {
    e.style.setProperty('display', 'none', 'important');
    e.style.setProperty('visibility', 'hidden', 'important');
    e.style.setProperty('pointer-events', 'none', 'important');
  };
  const textoCtrlG = /ctrl\s*\+?\s*g\b/i;

  // ---- revisa UN elemento; devuelve texto si lo oculto ----
  function revisar(e, streaming) {
    const t = e.tagName;
    if (!t || t === 'VIDEO' || t === 'CANVAS' || t === 'HTML' || t === 'BODY' || t === 'SCRIPT' || t === 'STYLE' || t === 'HEAD') return null;
    if (e.style && e.style.display === 'none') return null;
    const w = innerWidth, h = innerHeight;
    // 1) por texto "Ctrl+G": se oculta el contenedor mas grande que solo lleva ese texto
    const tx = e.childElementCount < 6 ? (e.textContent || '').trim() : '';
    if (tx.length > 0 && tx.length < 200 && textoCtrlG.test(tx) && !e.querySelector('video,canvas')) {
      let top = e;
      for (let i = 0; i < 5 && top.parentElement; i++) {
        const p = top.parentElement;
        if (p === document.body || p === document.documentElement) break;
        if ((p.textContent || '').trim().length > tx.length + 10 || p.querySelector('video,canvas')) break;
        top = p;
      }
      const pr = top.getBoundingClientRect();
      if (pr.width < w * 0.6 && pr.height < h * 0.6) { oculta(top); return 'texto ' + nombre(top); }
    }
    // 2) por color: bloque verde NVIDIA mientras hay stream (no botones ni enlaces)
    if (streaming && t !== 'BUTTON' && t !== 'A') {
      const rc0 = e.getBoundingClientRect();
      if (rc0.width < 20 || rc0.height < 20 || rc0.width >= w * 0.6 || rc0.height >= h * 0.6) return null;
      let cs; try { cs = getComputedStyle(e); } catch (_) { return null; }
      let verde = esVerde(cs.backgroundColor) || /118,\s*185,\s*0/.test(cs.backgroundImage);
      if (!verde) for (const ps of ['::before', '::after']) { try { if (esVerde(getComputedStyle(e, ps).backgroundColor)) verde = true; } catch (_) {} }
      if (verde && !e.closest('button,a,[role=button]')) {
        const rc = e.getBoundingClientRect();
        if (rc.width >= 20 && rc.height >= 20 && rc.width < w * 0.6 && rc.height < h * 0.6) {
          oculta(e); return 'color ' + nombre(e) + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height);
        }
      }
    }
    return null;
  }

  // ---- solo se revisan los nodos NUEVOS (lotes), en vez de recorrer toda la pagina cada pocos segundos ----
  let pendientes = new Map(), timer = 0; // nodo -> true si solo hay que mirar ese elemento (sin sus hijos)
  const programar = (n, solo) => { if (!pendientes.has(n) || !solo) pendientes.set(n, !!solo); if (!timer) timer = setTimeout(procesar, 300); };
  function procesar(tope) {
    timer = 0;
    const lote = [...pendientes]; pendientes = new Map();
    if (!ocultarVerde || document.hidden) return;
    const streaming = hayStream(), max = typeof tope === 'number' ? tope : 500;
    let vistos = 0, ultimo = null;
    for (const [n, solo] of lote) {
      if (n.nodeType === 1 && !n.isConnected) continue;
      let lista = [];
      try { lista = n.nodeType === 1 ? (solo ? [n] : [n, ...n.querySelectorAll('*')]) : [...n.querySelectorAll('*')]; } catch (_) {}
      for (const e of lista) {
        if (++vistos > max) break;
        const r = revisar(e, streaming);
        if (r) ultimo = r;
      }
    }
    if (ultimo) verdeInfo = 'verde oculto: ' + ultimo;
    else if (!/oculto/.test(verdeInfo)) verdeInfo = 'verde: nada en el DOM' + (streaming ? '' : ' (sin stream)');
  }
  const mo = new MutationObserver((muts) => {
    if (!ocultarVerde) return;
    for (const m of muts) {
      if (m.type === 'attributes') { if (m.target.nodeType === 1) programar(m.target, true); continue; }
      for (const n of m.addedNodes) {
        if (n.nodeType === 1) programar(n);
        else if (n.nodeType === 3 && m.target.nodeType === 1) programar(m.target, true); // texto que llega despues
      }
    }
  });
  const observar = (raiz) => { try { mo.observe(raiz, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] }); } catch (_) {} };
  observar(document);
  try {
    const o = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (i) {
      const r = o.call(this, i);
      try { sombras.add(r); observar(r); } catch (_) {}
      return r;
    };
  } catch (_) {}
  // respaldo: barrido completo cada 4 s, repartido en rebanadas de ~3 ms para no causar tirones
  let barriendo = false;
  function barridoCompleto() {
    if (barriendo || !ocultarVerde || document.hidden) return;
    barriendo = true;
    const streaming = hayStream();
    let todos = [];
    for (const r of raices()) { try { todos = todos.concat(Array.from(r.querySelectorAll('*'))); } catch (_) {} }
    let i = 0, ultimo = null;
    const rebanada = () => {
      const t0 = performance.now();
      while (i < todos.length && performance.now() - t0 < 3) { const r = revisar(todos[i++], streaming); if (r) ultimo = r; }
      if (i < todos.length) setTimeout(rebanada, 25);
      else { barriendo = false; if (ultimo) verdeInfo = 'verde oculto: ' + ultimo; }
    };
    rebanada();
  }
  setInterval(barridoCompleto, 4000);

  // ---- panel de diagnostico (F1) ----
  const reg = (t, k) => window.addEventListener(t, (e) => {
    if (!verPanel) return;
    cnt[k]++;
    last = t + ' ' + (e.pointerType || '') + (e.isTrusted ? '' : ' (nova)') + ' x' + Math.round(e.clientX) + ' y' + Math.round(e.clientY) +
      ' mv' + e.movementX + ',' + e.movementY + ' b' + e.buttons;
  }, true);
  reg('mousemove', 'mm'); reg('pointermove', 'pm'); reg('mousedown', 'md'); reg('mouseup', 'mu');
  window.addEventListener('touchstart', () => { if (verPanel) cnt.tc++; }, true);
  document.addEventListener('pointerlockchange', () => cnt.pl++);

  window.addEventListener('keydown', (e) => {
    if (e.code === 'F1') {
      verPanel = !verPanel;
      try { localStorage.setItem(LSP, verPanel ? '1' : '0'); } catch (_) {}
      e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'F2') { // activar / desactivar el ocultador del aviso verde
      ocultarVerde = !ocultarVerde;
      try { localStorage.setItem(LSV, ocultarVerde ? '1' : '0'); } catch (_) {}
      verdeInfo = 'ocultar verde: ' + (ocultarVerde ? 'SI' : 'NO');
      e.preventDefault(); e.stopImmediatePropagation();
    }
  }, true);

  let p;
  function pintar() {
    if (!verPanel) { if (p) p.style.display = 'none'; return; }
    if (!document.body) return;
    if (!p) {
      p = document.createElement('div');
      p.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483646;background:rgba(0,0,0,.6);color:#0f0;' +
        'font:10px monospace;padding:3px 5px;border-radius:4px;pointer-events:none;white-space:pre;max-width:60vw';
      document.body.appendChild(p);
    }
    p.style.display = '';
    const lk = window.__novaLocked && window.__novaLocked();
    p.textContent = 'v0.13 mm' + cnt.mm + ' pm' + cnt.pm + ' md' + cnt.md + ' mu' + cnt.mu + ' lock' + cnt.pl + ' touch' + cnt.tc +
      '\n' + (window.NovaNative ? 'captura:' + (lk ? 'SI' : 'no') : 'sin puente nativo') + ' ' + (window.__novaDbg || '') + ' ' + (window.__novaTel ? window.__novaTel() : '') +
      '\n' + last + '\n' + verdeInfo;
  }
  setInterval(pintar, 500);
})();
