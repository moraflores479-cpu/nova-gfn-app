(() => {
  'use strict';
  // NOVA Codec v0.12: evita AV1 (en la mayoria de telefonos se decodifica por software = FPS muy bajos)
  // y deja al HUD leer el codec / decodificador reales del stream (getStats).
  // Modos (se guardan): 'auto' = sin AV1 | 'h264' = solo H.264 | 'todo' = sin filtro.
  const LSC = 'nova_codec';
  let modoC = 'auto';
  try { const g = localStorage.getItem(LSC); if (g === 'auto' || g === 'h264' || g === 'todo') modoC = g; } catch (_) {}
  window.__novaCodec = () => modoC;
  window.__novaSetCodec = (m) => { modoC = m; try { localStorage.setItem(LSC, m); } catch (_) {} };

  const pcs = [];
  window.__novaPCs = pcs;
  try {
    const Orig = window.RTCPeerConnection;
    if (Orig) {
      const W = function (...a) { const pc = new Orig(...a); pcs.push(pc); if (pcs.length > 6) pcs.shift(); return pc; };
      W.prototype = Orig.prototype;
      Object.setPrototypeOf(W, Orig);
      window.RTCPeerConnection = W;
      if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = W;
    }
  } catch (_) {}

  const apoyo = /^video\/(rtx|red|ulpfec|flexfec-03)$/i;
  const filtra = (lista) => {
    if (modoC === 'todo' || !lista) return lista;
    return lista.filter((c) => {
      const m = String(c.mimeType || '').toLowerCase();
      if (!m.startsWith('video/')) return true;
      if (modoC === 'h264') return m === 'video/h264' || apoyo.test(m);
      return m !== 'video/av1';
    });
  };
  try {
    const RR = window.RTCRtpReceiver;
    if (RR && RR.getCapabilities) {
      const og = RR.getCapabilities.bind(RR);
      RR.getCapabilities = function (kind) {
        const c = og(kind);
        if (!c || kind !== 'video') return c;
        return Object.assign({}, c, { codecs: filtra(c.codecs) });
      };
    }
    const T = window.RTCRtpTransceiver;
    if (T && T.prototype.setCodecPreferences) {
      const os = T.prototype.setCodecPreferences;
      T.prototype.setCodecPreferences = function (codecs) {
        try { return os.call(this, filtra(codecs)); } catch (_) { return os.call(this, codecs); }
      };
    }
    // otras vias por las que una pagina pregunta si el navegador "soporta" AV1
    const esAv1 = (s) => /av01|av1/i.test(String(s || ''));
    if (window.MediaCapabilities && MediaCapabilities.prototype.decodingInfo) {
      const od = MediaCapabilities.prototype.decodingInfo;
      MediaCapabilities.prototype.decodingInfo = function (cfg) {
        if (modoC !== 'todo' && cfg && cfg.video && esAv1(cfg.video.contentType)) {
          return Promise.resolve({ supported: false, smooth: false, powerEfficient: false });
        }
        return od.call(this, cfg);
      };
    }
    if (window.MediaSource && MediaSource.isTypeSupported) {
      const oi = MediaSource.isTypeSupported.bind(MediaSource);
      MediaSource.isTypeSupported = (t) => (modoC !== 'todo' && esAv1(t) ? false : oi(t));
    }
    if (window.HTMLMediaElement) {
      const oc = HTMLMediaElement.prototype.canPlayType;
      HTMLMediaElement.prototype.canPlayType = function (t) { return modoC !== 'todo' && esAv1(t) ? '' : oc.call(this, t); };
    }
  } catch (_) {}

  // estadisticas del video entrante para el HUD
  window.__novaStats = async () => {
    const lista = pcs.filter((p) => p.connectionState !== 'closed' && p.connectionState !== 'failed');
    const pc = lista.reverse().find((p) => p.connectionState === 'connected') || lista[0];
    if (!pc) return null;
    const rep = await pc.getStats();
    const codecs = {}; let out = null;
    rep.forEach((r) => { if (r.type === 'codec') codecs[r.id] = r; });
    rep.forEach((r) => {
      if (r.type === 'inbound-rtp' && (r.kind === 'video' || r.mediaType === 'video')) {
        const c = codecs[r.codecId];
        out = {
          codec: c ? String(c.mimeType || '').replace(/^video\//i, '') : '?',
          decoder: r.decoderImplementation || '?',
          w: r.frameWidth, h: r.frameHeight, fps: r.framesPerSecond,
          decoded: r.framesDecoded, dropped: r.framesDropped, totalDecode: r.totalDecodeTime, lost: r.packetsLost,
          jitter: r.jitterBufferEmittedCount ? (r.jitterBufferDelay / r.jitterBufferEmittedCount) * 1000 : null,
        };
      }
    });
    return out;
  };
})();
