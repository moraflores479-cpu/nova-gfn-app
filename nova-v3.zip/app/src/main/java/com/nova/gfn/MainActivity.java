package com.nova.gfn;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private WebView web;
    private String js = "";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private String leer(String f) {
        try (InputStream in = getAssets().open(f)) {
            byte[] b = new byte[in.available()]; in.read(b); return new String(b, "UTF-8") + "\n";
        } catch (Exception e) { return ""; }
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        js = leer("pcmode.js") + leer("movefix.js") + leer("fit.js") + leer("diag.js");
        web = new WebView(this);
        setContentView(web);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setUserAgentString(UA);
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);
        web.setWebChromeClient(new WebChromeClient());
        boolean doc = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (doc) WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap b) {
                if (!doc && url != null && url.contains("geforcenow.com")) v.evaluateJavascript(js, null);
            }
        });
        web.loadUrl("https://play.geforcenow.com/");
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
