(() => {
  'use strict';
  // Panel de diagnostico + ocultador robusto del cuadro verde (NOVA v0.2)
  const VERDE = 'rgb(118, 185, 0)';
  const cnt = { mm: 0, pm: 0, md: 0, mu: 0, pl: 0, tc: 0 };
  let last = '-', verdeInfo = '-';
  const sombras = new Set();
  try {
    const o = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (i) { const r = o.call(this, i); try { sombras.add(r); } catch (_) {} return r; };
  } catch (_) {}
  const reg = (t, k) => window.addEventListener(t, (e) => {
    cnt[k]++;
    last = t + ' ' + (e.pointerType || '') + ' x' + Math.round(e.clientX) + ' y' + Math.round(e.clientY) +
      ' mv' + e.movementX + ',' + e.movementY + ' b' + e.buttons;
  }, true);
  reg('mousemove', 'mm'); reg('pointermove', 'pm'); reg('mousedown', 'md'); reg('mouseup', 'mu');
  window.addEventListener('touchstart', () => cnt.tc++, true);
  document.addEventListener('pointerlockchange', () => cnt.pl++);

  const nombre = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
    (typeof e.className === 'string' && e.className ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');

  const esVerde = (c) => {
    const m = String(c).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    return !!m && Math.abs(m[1] - 118) < 30 && Math.abs(m[2] - 185) < 30 && m[3] < 50;
  };
  function barrer() {
    if (!document.body) return;
    const w = innerWidth, h = innerHeight;
    const cand = [];
    let ocultos = 0;
    for (const r of [document, ...sombras]) {
      let lista = [];
      try { lista = r.querySelectorAll('*'); } catch (_) {}
      for (const e of lista) {
        const t = e.tagName;
        if (t === 'VIDEO' || t === 'CANVAS' || t === 'HTML' || t === 'BODY' || t === 'SCRIPT' || t === 'STYLE') continue;
        const rc = e.getBoundingClientRect();
        if (rc.width < 30 || rc.height < 40 || rc.width > w * 0.25 || rc.height > h * 0.8 || rc.left < w * 0.75) continue;
        let cs; try { cs = getComputedStyle(e); } catch (_) { continue; }
        let verde = esVerde(cs.backgroundColor) || /118,\s*185,\s*0/.test(cs.backgroundImage);
        if (!verde) {
          for (const ps of ['::before', '::after']) {
            try { if (esVerde(getComputedStyle(e, ps).backgroundColor)) verde = true; } catch (_) {}
          }
        }
        if (verde) {
          e.style.setProperty('visibility', 'hidden', 'important');
          e.style.setProperty('opacity', '0', 'important');
          e.style.setProperty('pointer-events', 'none', 'important');
          ocultos++;
          verdeInfo = 'oculto ' + nombre(e);
        } else if (cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && cand.length < 3) {
          cand.push(nombre(e) + ' ' + cs.backgroundColor.replace(/\s/g, ''));
        }
      }
    }
    if (!ocultos) verdeInfo = 'verde no hallado; borde der: ' + (cand.join(' | ') || 'nada');
  }
  setInterval(barrer, 1000);

  let p;
  function pintar() {
    if (!document.body) return;
    if (!p) {
      p = document.createElement('div');
      p.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483647;background:rgba(0,0,0,.6);color:#0f0;' +
        'font:10px monospace;padding:3px 5px;border-radius:4px;pointer-events:none;white-space:pre;max-width:60vw';
      document.body.appendChild(p);
    }
    p.textContent = 'mm' + cnt.mm + ' pm' + cnt.pm + ' md' + cnt.md + ' mu' + cnt.mu + ' lock' + cnt.pl + ' touch' + cnt.tc +
      ' f' + (window.__novaMvFactor ? window.__novaMvFactor() : '-') + '\n' + last + '\n' + verdeInfo + '\nlockEl:' + (document.pointerLockElement ? 'si' : 'no');
  }
  setInterval(pintar, 250);
})();
