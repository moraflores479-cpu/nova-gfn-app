# NOVA GFN
WebView para GeForce NOW en modo PC (scripts incluidos en app/src/main/assets). La APK se compila sola en Actions y queda en Releases ("latest").
