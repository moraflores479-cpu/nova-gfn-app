(() => {
  'use strict';
  // Panel de diagnostico + ocultador del aviso verde "Ctrl+G" (NOVA v0.4)
  const cnt = { mm: 0, pm: 0, md: 0, mu: 0, pl: 0, tc: 0 };
  let last = '-', verdeInfo = '-';
  const LSV = 'nova_hide_green';
  let ocultarVerde = true;
  try { ocultarVerde = localStorage.getItem(LSV) !== '0'; } catch (_) {}
  const sombras = new Set();
  try {
    const o = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (i) { const r = o.call(this, i); try { sombras.add(r); } catch (_) {} return r; };
  } catch (_) {}
  const reg = (t, k) => window.addEventListener(t, (e) => {
    cnt[k]++;
    last = t + ' ' + (e.pointerType || '') + (e.isTrusted ? '' : ' (nova)') + ' x' + Math.round(e.clientX) + ' y' + Math.round(e.clientY) +
      ' mv' + e.movementX + ',' + e.movementY + ' b' + e.buttons;
  }, true);
  reg('mousemove', 'mm'); reg('pointermove', 'pm'); reg('mousedown', 'md'); reg('mouseup', 'mu');
  window.addEventListener('touchstart', () => cnt.tc++, true);
  document.addEventListener('pointerlockchange', () => cnt.pl++);

  const nombre = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
    (typeof e.className === 'string' && e.className ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
  const esVerde = (c) => {
    const m = String(c).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
    return !!m && (m[4] === undefined || +m[4] > 0.3) && Math.abs(m[1] - 118) < 35 && Math.abs(m[2] - 185) < 35 && m[3] < 60;
  };
  const raices = () => [document, ...sombras];
  const hayStream = () => {
    for (const r of raices()) {
      let vs = []; try { vs = r.querySelectorAll('video'); } catch (_) {}
      for (const v of vs) if (v.videoWidth > 0 && !v.paused) return true;
    }
    return false;
  };
  const oculta = (e) => {
    e.style.setProperty('display', 'none', 'important');
    e.style.setProperty('visibility', 'hidden', 'important');
    e.style.setProperty('pointer-events', 'none', 'important');
  };
  const textoCtrlG = /ctrl\s*\+?\s*g\b/i;

  function barrer() {
    if (!document.body) return;
    const w = innerWidth, h = innerHeight;
    if (!ocultarVerde) { verdeInfo = 'ocultar verde: NO (F7 para activar)'; return; }
    const streaming = hayStream();
    const ocultos = [], cand = [];
    for (const r of raices()) {
      let lista = []; try { lista = r.querySelectorAll('*'); } catch (_) {}
      for (const e of lista) {
        const t = e.tagName;
        if (t === 'VIDEO' || t === 'CANVAS' || t === 'HTML' || t === 'BODY' || t === 'SCRIPT' || t === 'STYLE' || t === 'HEAD') continue;
        if (e.style && e.style.display === 'none') continue;
        const rc = e.getBoundingClientRect();
        if (rc.width < 8 || rc.height < 8 || rc.width > w * 0.6 || rc.height > h * 0.6) continue;
        if (rc.bottom < 0 || rc.right < 0 || rc.left > w || rc.top > h) continue;
        let cs; try { cs = getComputedStyle(e); } catch (_) { continue; }
        if (cs.display === 'none' || cs.visibility === 'hidden') continue;
        // 1) por texto: aviso "Ctrl+G"; se oculta el contenedor mas grande que solo lleva ese texto
        let porTexto = false;
        const tx = (e.textContent || '').trim();
        if (tx.length > 0 && tx.length < 200 && textoCtrlG.test(tx) && !e.querySelector('video,canvas')) {
          let top = e;
          for (let i = 0; i < 5 && top.parentElement; i++) {
            const p = top.parentElement, pr = p.getBoundingClientRect();
            if (p === document.body || p === document.documentElement) break;
            if ((p.textContent || '').trim().length > tx.length + 10 || pr.width > w * 0.6 || pr.height > h * 0.6 || p.querySelector('video,canvas')) break;
            top = p;
          }
          oculta(top); ocultos.push('texto ' + nombre(top)); porTexto = true;
        }
        if (porTexto) continue;
        // 2) por color: bloque verde NVIDIA, solo mientras hay stream y no es un boton/enlace
        if (streaming) {
          let verde = esVerde(cs.backgroundColor) || /118,\s*185,\s*0/.test(cs.backgroundImage);
          if (!verde) for (const ps of ['::before', '::after']) { try { if (esVerde(getComputedStyle(e, ps).backgroundColor)) verde = true; } catch (_) {} }
          if (verde && rc.width >= 20 && rc.height >= 20 && t !== 'BUTTON' && t !== 'A' && !e.closest('button,a,[role=button]')) {
            oculta(e); ocultos.push('color ' + nombre(e) + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height) + '@' + Math.round(rc.left) + ',' + Math.round(rc.top));
            continue;
          }
        }
        if (cand.length < 3 && (cs.position === 'fixed' || cs.position === 'absolute') && cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && rc.width < w * 0.4 && rc.height < h * 0.4) {
          cand.push(nombre(e) + ' ' + cs.backgroundColor.replace(/\s/g, '') + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height) + '@' + Math.round(rc.left) + ',' + Math.round(rc.top));
        }
      }
    }
    if (ocultos.length) verdeInfo = 'verde oculto: ' + ocultos[ocultos.length - 1];
    else verdeInfo = 'verde: nada en el DOM' + (streaming ? '' : ' (sin stream)') + (cand.length ? '; cajas: ' + cand.join(' | ') : '');
  }
  setInterval(barrer, 700);

  // F7 = activar / desactivar el ocultador de verde (por si oculta algo que si quieres ver)
  window.addEventListener('keydown', (e) => {
    if (e.code !== 'F7') return;
    ocultarVerde = !ocultarVerde;
    try { localStorage.setItem(LSV, ocultarVerde ? '1' : '0'); } catch (_) {}
    verdeInfo = 'ocultar verde: ' + (ocultarVerde ? 'SI' : 'NO');
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);

  let p;
  function pintar() {
    if (!document.body) return;
    if (!p) {
      p = document.createElement('div');
      p.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483647;background:rgba(0,0,0,.6);color:#0f0;' +
        'font:10px monospace;padding:3px 5px;border-radius:4px;pointer-events:none;white-space:pre;max-width:60vw';
      document.body.appendChild(p);
    }
    const lk = window.__novaLocked && window.__novaLocked();
    p.textContent = 'v0.7 mm' + cnt.mm + ' pm' + cnt.pm + ' md' + cnt.md + ' mu' + cnt.mu + ' lock' + cnt.pl + ' touch' + cnt.tc +
      '\n' + (window.NovaNative ? 'captura:' + (lk ? 'SI f' + (window.__novaCapFactor ? window.__novaCapFactor() : '-') : 'no') : 'sin puente nativo') +
      ' f' + (window.__novaMvFactor ? window.__novaMvFactor() : '-') + '\n' + (window.__novaDbg || '') + ' ' + (window.__novaTel ? window.__novaTel() : '') + '\n' + last + '\n' + verdeInfo;
  }
  setInterval(pintar, 250);
})();
