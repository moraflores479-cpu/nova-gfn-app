// ==UserScript==
// @name         NOVA Screen Fit v2 for GeForce NOW
// @namespace    nova-cloud
// @version      0.2.0
// @description  Version mas agresiva: busca el video (tambien dentro de shadow DOM y canvas), quita lo que lo limita y lo ajusta a toda la pantalla. F6 = modo, F7 = diagnostico.
// @match        https://play.geforcenow.com/*
// @match        https://*.geforcenow.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  'use strict';

  // ───────── CONFIGURACIÓN ─────────
  const CONFIG = {
    modoInicial: 'estirar',     // 'estirar' | 'recortar' | 'normal'
    teclaModo: 'F6',
    teclaDiagnostico: 'F7',
    ocultarCuadroVerde: true,
  };
  // ──────────────────────────────────

  const MODOS = ['estirar', 'recortar', 'normal'];
  const LS = 'nova_fit2_modo';
  let modo = CONFIG.modoInicial;
  try {
    const g = localStorage.getItem(LS);
    if (MODOS.includes(g)) modo = g;
  } catch (_) {}

  // Guarda las raíces shadow DOM (aunque sean "closed") para poder buscar dentro
  const sombras = new Set();
  try {
    const orig = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (init) {
      const r = orig.call(this, init);
      try { sombras.add(r); } catch (_) {}
      return r;
    };
  } catch (_) {}

  const originales = new Map(); // elemento -> style.cssText original
  function guardar(el) {
    if (!originales.has(el)) originales.set(el, el.style.cssText);
  }
  function restaurar() {
    for (const [el, css] of originales) {
      try { el.style.cssText = css; } catch (_) {}
    }
    originales.clear();
  }
  const fijar = (el, p, v) => el.style.setProperty(p, v, 'important');

  function medios() {
    const out = [];
    for (const r of [document, ...sombras]) {
      try { r.querySelectorAll('video,canvas').forEach((e) => out.push(e)); } catch (_) {}
    }
    return out;
  }

  function elegir() {
    let mejor = null, area = 0;
    for (const e of medios()) {
      const r = e.getBoundingClientRect();
      let a = r.width * r.height;
      if (e.tagName === 'VIDEO' && e.videoWidth) a *= 2; // prefiere video con imagen real
      if (a > area) { area = a; mejor = e; }
    }
    return mejor;
  }

  function ancestros(el) {
    const out = [];
    const sube = (n) => n.parentElement || (n.getRootNode && n.getRootNode().host) || null;
    let n = sube(el);
    while (n && n !== document.documentElement) {
      out.push(n);
      n = sube(n);
    }
    return out;
  }

  function aplicar() {
    if (modo === 'normal') { restaurar(); return; }
    const v = elegir();
    if (!v) return;
    guardar(v);
    fijar(v, 'position', 'fixed');
    fijar(v, 'left', '0');
    fijar(v, 'top', '0');
    fijar(v, 'right', 'auto');
    fijar(v, 'bottom', 'auto');
    fijar(v, 'width', '100vw');
    fijar(v, 'height', '100vh');
    fijar(v, 'min-width', '0');
    fijar(v, 'min-height', '0');
    fijar(v, 'max-width', 'none');
    fijar(v, 'max-height', 'none');
    fijar(v, 'margin', '0');
    fijar(v, 'padding', '0');
    fijar(v, 'transform', 'none');
    fijar(v, 'object-fit', modo === 'estirar' ? 'fill' : 'cover');
    // Lo que crea un "bloque contenedor" impide que position:fixed use toda la pantalla
    for (const a of ancestros(v)) {
      guardar(a);
      fijar(a, 'transform', 'none');
      fijar(a, 'filter', 'none');
      fijar(a, 'perspective', 'none');
      fijar(a, 'contain', 'none');
      fijar(a, 'will-change', 'auto');
      fijar(a, 'backdrop-filter', 'none');
    }
  }

  // Heurística: recuadro verde de NVIDIA (#76b900), grande, sin texto ni hijos y fijo/absoluto
  function ocultarVerde() {
    if (!CONFIG.ocultarCuadroVerde || !document.body) return;
    for (const r of [document, ...sombras]) {
      let lista = [];
      try { lista = r.querySelectorAll('*'); } catch (_) {}
      for (const el of lista) {
        if (el.children.length > 0 || el.tagName === 'VIDEO' || el.tagName === 'CANVAS' || el.tagName === 'BUTTON') continue;
        if (el.textContent && el.textContent.trim() !== '') continue;
        const cs = getComputedStyle(el);
        if (cs.backgroundColor !== 'rgb(118, 185, 0)') continue;
        if (cs.position !== 'fixed' && cs.position !== 'absolute') continue;
        const rc = el.getBoundingClientRect();
        if (rc.width >= 60 && rc.height >= 60 && cs.visibility !== 'hidden') {
          el.style.setProperty('visibility', 'hidden', 'important');
        }
      }
    }
  }

  // ───────── Avisos y diagnóstico ─────────
  let panel, tm;
  function mostrar(texto, ms) {
    if (!document.body) return;
    if (!panel) {
      panel = document.createElement('div');
      panel.style.cssText = 'position:fixed;top:8px;right:8px;z-index:2147483647;background:rgba(0,0,0,.78);' +
        'color:#fff;font:11px monospace;padding:6px 9px;border-radius:6px;pointer-events:none;' +
        'white-space:pre;max-width:90vw;transition:opacity .3s';
      document.body.appendChild(panel);
    }
    panel.textContent = texto;
    panel.style.opacity = '1';
    clearTimeout(tm);
    tm = setTimeout(() => { panel.style.opacity = '0'; }, ms || 1800);
  }

  function diagnostico() {
    const lineas = ['NOVA Screen Fit v2 | modo: ' + modo,
      'viewport: ' + innerWidth + 'x' + innerHeight + ' dpr:' + devicePixelRatio,
      'shadow roots: ' + sombras.size];
    const ms = medios();
    lineas.push('video/canvas: ' + ms.length);
    ms.slice(0, 5).forEach((e) => {
      const r = e.getBoundingClientRect();
      lineas.push('- ' + e.tagName + ' ' + Math.round(r.width) + 'x' + Math.round(r.height) +
        (e.videoWidth ? ' src ' + e.videoWidth + 'x' + e.videoHeight : '') +
        ' @' + Math.round(r.left) + ',' + Math.round(r.top));
    });
    mostrar(lineas.join('\n'), 9000);
  }

  window.addEventListener('keydown', (e) => {
    if (e.code === CONFIG.teclaModo) {
      modo = MODOS[(MODOS.indexOf(modo) + 1) % MODOS.length];
      try { localStorage.setItem(LS, modo); } catch (_) {}
      aplicar();
      mostrar('Pantalla: ' + modo);
    } else if (e.code === CONFIG.teclaDiagnostico) {
      diagnostico();
    } else {
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);

  setInterval(aplicar, 400);
  setInterval(ocultarVerde, 1000);
  window.addEventListener('resize', aplicar);
  window.addEventListener('DOMContentLoaded', () => mostrar('NOVA Screen Fit v2: ' + modo));
})();
