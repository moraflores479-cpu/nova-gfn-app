// ==UserScript==
// @name         NOVA Mouse Scale for GeForce NOW
// @namespace    nova-cloud
// @version      0.1.0
// @description  Reduce la velocidad del movimiento del mouse (camara) antes de que llegue a GeForce NOW. F9 = mas lento, F10 = mas rapido.
// @match        https://play.geforcenow.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  'use strict';

  // ───────── CONFIGURACIÓN ─────────
  const CONFIG = {
    factorInicial: 0.35,  // 1 = sin cambio. 0.35 = 35 % de la velocidad original
    paso: 0.05,           // cuanto cambian F9 / F10
    minimo: 0.05,
    maximo: 1.5,
    teclaMenos: 'F9',
    teclaMas: 'F10',
    soloConMouseCapturado: false, // false = escala siempre (el juego puede no usar pointer lock en tu navegador)
  };
  // ──────────────────────────────────

  const LS = 'nova_mouse_factor';
  let factor = CONFIG.factorInicial;
  try {
    const g = parseFloat(localStorage.getItem(LS));
    if (g > 0) factor = g;
  } catch (_) {}

  const descX = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'movementX');
  const descY = Object.getOwnPropertyDescriptor(MouseEvent.prototype, 'movementY');
  if (!descX || !descY || !descX.get || !descY.get) return; // el navegador no lo expone

  const cache = new WeakMap(); // evita calcular dos veces por evento
  let restoX = 0, restoY = 0;  // acumula decimales para no perder movimientos pequeños

  function escalado(ev) {
    let c = cache.get(ev);
    if (c) return c;
    const ox = descX.get.call(ev), oy = descY.get.call(ev);
    if (CONFIG.soloConMouseCapturado && !document.pointerLockElement) {
      c = { x: ox, y: oy };
    } else {
      const fx = ox * factor + restoX, fy = oy * factor + restoY;
      const rx = Math.round(fx), ry = Math.round(fy);
      restoX = fx - rx; restoY = fy - ry;
      c = { x: rx, y: ry };
    }
    cache.set(ev, c);
    return c;
  }

  Object.defineProperty(MouseEvent.prototype, 'movementX', {
    get() { return escalado(this).x; }, configurable: true,
  });
  Object.defineProperty(MouseEvent.prototype, 'movementY', {
    get() { return escalado(this).y; }, configurable: true,
  });

  // ───────── Ajuste en vivo ─────────
  let el, tm;
  function aviso(t) {
    if (!document.body) return;
    if (!el) {
      el = document.createElement('div');
      el.style.cssText = 'position:fixed;bottom:8px;left:8px;z-index:2147483647;background:rgba(0,0,0,.7);' +
        'color:#fff;font:12px sans-serif;padding:5px 9px;border-radius:6px;pointer-events:none;transition:opacity .3s';
      document.body.appendChild(el);
    }
    el.textContent = t;
    el.style.opacity = '1';
    clearTimeout(tm);
    tm = setTimeout(() => { el.style.opacity = '0'; }, 1800);
  }

  window.addEventListener('keydown', (e) => {
    if (e.code !== CONFIG.teclaMenos && e.code !== CONFIG.teclaMas) return;
    const d = (e.code === CONFIG.teclaMas) ? CONFIG.paso : -CONFIG.paso;
    factor = Math.min(CONFIG.maximo, Math.max(CONFIG.minimo, Math.round((factor + d) * 100) / 100));
    try { localStorage.setItem(LS, String(factor)); } catch (_) {}
    aviso('Mouse: ' + Math.round(factor * 100) + ' %');
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);

  window.addEventListener('DOMContentLoaded', () => aviso('NOVA Mouse Scale: ' + Math.round(factor * 100) + ' %'));
})();
