(() => {
  'use strict';
  // NOVA Capture v0.4: "mouse de maquina virtual".
  // WebView no soporta Pointer Lock, asi que lo emulamos con la captura nativa de Android
  // (requestPointerCapture): el cursor desaparece y llega movimiento relativo infinito,
  // igual que al hacer clic dentro de una VM. Los eventos se entregan a la pagina
  // como mousemove/pointermove con movementX/Y, mousedown/up y wheel.
  const nat = window.NovaNative;
  if (!nat || typeof nat.capture !== 'function') return;

  const LS = 'nova_cap_factor';
  let factor = 0.4;
  try { const g = parseFloat(localStorage.getItem(LS)); if (g > 0) factor = g; } catch (_) {}
  let lockEl = null, pend = null, cur = 0, resto = { x: 0, y: 0 }, vx = 0, vy = 0, realBtn = 0;
  let lr = null; // ultima posicion del mouse real, para continuar desde ahi
  ['mousemove', 'pointermove'].forEach((t) => window.addEventListener(t, (e) => { if (e.isTrusted && e.pointerType !== 'touch') lr = { x: e.clientX, y: e.clientY }; }, true));
  const tel = { n: 0, x: 0, y: 0 };
  window.__novaTel = () => 'mvJS n' + tel.n + ' ult ' + tel.x + ',' + tel.y;
  window.__novaLocked = () => !!lockEl;
  window.__novaCapFactor = () => factor;

  // ---- API de Pointer Lock falsa pero fiel a la real ----
  try {
    Object.defineProperty(Document.prototype, 'pointerLockElement', { get() { return lockEl; }, configurable: true });
    Object.defineProperty(Document.prototype, 'mozPointerLockElement', { get() { return lockEl; }, configurable: true });
  } catch (_) {}
  const evDoc = (t) => { try { document.dispatchEvent(new Event(t, { bubbles: true })); } catch (_) {} };
  Element.prototype.requestPointerLock = function () {
    const el = this;
    return new Promise((res, rej) => {
      if (lockEl === el) { res(); return; }
      pend = { el, res, rej };
      nat.capture(true);
      setTimeout(() => {
        if (pend && pend.el === el) {
          const p = pend; pend = null;
          evDoc('pointerlockerror');
          try { p.rej(new DOMException('No se pudo capturar el mouse', 'NotAllowedError')); } catch (_) {}
        }
      }, 1500);
    });
  };
  Document.prototype.exitPointerLock = function () { nat.capture(false); };

  // ---- estado de botones reales (para no dejar clics pegados al capturar) ----
  ['mousedown', 'mouseup', 'pointerdown', 'pointerup'].forEach((t) =>
    window.addEventListener(t, (e) => { if (e.isTrusted) realBtn = e.buttons; }, true));

  const bit = [1, 4, 2, 8, 16]; // button 0..4 -> bit de MouseEvent.buttons
  const base = (extra) => Object.assign({ bubbles: true, cancelable: true, composed: true, view: window,
    clientX: vx, clientY: vy, screenX: vx, screenY: vy, buttons: cur, pointerType: 'mouse', pointerId: 1, isPrimary: true }, extra);
  const fire = (name, init, wheel) => {
    const el = lockEl; if (!el) return;
    try {
      let ev;
      if (wheel) ev = new WheelEvent(name, init);
      else if (name.startsWith('pointer')) ev = new PointerEvent(name, init);
      else ev = new MouseEvent(name, init);
      // WebView puede ignorar movementX/Y del constructor: los fijamos como propiedad propia del evento
      if (init.movementX !== undefined) {
        Object.defineProperty(ev, 'movementX', { value: init.movementX, configurable: true });
        Object.defineProperty(ev, 'movementY', { value: init.movementY, configurable: true });
      }
      if (name.startsWith('pointer')) {
        Object.defineProperty(ev, 'getCoalescedEvents', { value: () => [ev], configurable: true });
        Object.defineProperty(ev, 'getPredictedEvents', { value: () => [], configurable: true });
      }
      el.dispatchEvent(ev);
    } catch (_) {}
  };
  const setBtn = (i, down) => {
    const b = bit[i]; if (!b || !!(cur & b) === down) return;
    cur = down ? (cur | b) : (cur & ~b);
    fire(down ? 'pointerdown' : 'pointerup', base({ button: i }));
    fire(down ? 'mousedown' : 'mouseup', base({ button: i, detail: 1 }));
    if (!down && i === 0) fire('click', base({ button: 0, detail: 1 }));
  };
  const reconcile = (mask) => { for (let i = 0; i < 5; i++) setBtn(i, !!(mask & bit[i])); };

  window.__novaIn = (dx, dy, mask, sx, sy, dbg) => {
    window.__novaDbg = dbg || '';
    if (!lockEl) return;
    if (dx || dy) {
      const fx = dx * factor + resto.x, fy = dy * factor + resto.y;
      const rx = Math.round(fx), ry = Math.round(fy);
      resto = { x: fx - rx, y: fy - ry };
      if (rx || ry) {
        tel.n++; tel.x = rx; tel.y = ry;
        vx = Math.min(innerWidth - 1, Math.max(0, vx + rx)); vy = Math.min(innerHeight - 1, Math.max(0, vy + ry));
        fire('pointerrawupdate', base({ movementX: rx, movementY: ry, cancelable: false }));
        fire('pointermove', base({ movementX: rx, movementY: ry }));
        fire('mousemove', base({ movementX: rx, movementY: ry }));
      }
    }
    reconcile(mask);
    if (sx || sy) fire('wheel', base({ deltaX: -sx * 100, deltaY: -sy * 100, deltaMode: 0 }), true);
  };

  window.__novaCap = (on) => {
    if (on) {
      const p = pend; pend = null;
      lockEl = (p && p.el) || document.querySelector('video') || document.body;
      vx = lr ? lr.x : Math.round(innerWidth / 2); vy = lr ? lr.y : Math.round(innerHeight / 2);
      cur = realBtn; resto = { x: 0, y: 0 };
      evDoc('pointerlockchange');
      if (p) { try { p.res(); } catch (_) {} }
      aviso('Mouse capturado  (' + Math.round(factor * 100) + '%)  F8 = soltar');
    } else {
      reconcile(0);
      const habia = !!lockEl; lockEl = null; cur = 0;
      if (habia) { evDoc('pointerlockchange'); aviso('Mouse liberado'); }
    }
  };

  // ---- teclas: F8 captura/suelta (Ctrl+G de GFN tambien), F9/F10 velocidad. Esc NO suelta ----
  window.addEventListener('keydown', (e) => {
    if (e.code === 'F8') {
      if (lockEl) nat.capture(false);
      else { const v = document.querySelector('video') || document.body; v.requestPointerLock(); }
      e.preventDefault(); e.stopImmediatePropagation(); return;
    }
    if (lockEl && (e.code === 'F9' || e.code === 'F10')) {
      factor = Math.min(3, Math.max(0.05, Math.round((factor + (e.code === 'F10' ? 0.05 : -0.05)) * 100) / 100));
      try { localStorage.setItem(LS, String(factor)); } catch (_) {}
      aviso('Velocidad del mouse: ' + Math.round(factor * 100) + '%');
      e.preventDefault(); e.stopImmediatePropagation();
    }
  }, true);

  let el, tm;
  function aviso(t) {
    if (!document.body) return;
    if (!el) {
      el = document.createElement('div');
      el.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483647;background:rgba(0,0,0,.7);' +
        'color:#fff;font:12px sans-serif;padding:5px 9px;border-radius:6px;pointer-events:none;transition:opacity .3s';
      document.body.appendChild(el);
    }
    el.textContent = t; el.style.opacity = '1';
    clearTimeout(tm); tm = setTimeout(() => { el.style.opacity = '0'; }, 2200);
  }
})();
