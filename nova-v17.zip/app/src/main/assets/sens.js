(() => {
  'use strict';
  // NOVA Sens: panel pequeno de sensibilidad (F4 o boton ⚙). Usa window.__novaSens de capture.js.
  if (window.__novaModo === 'movil' || !window.__novaSens) return;
  const S = window.__novaSens;
  let host, root, abierto = false, el = {};
  const css = `
    :host { all: initial }
    .btn { position: fixed; top: 6px; left: 6px; width: 26px; height: 26px; border-radius: 13px; background: rgba(15,18,32,.55);
      color: #cfd6f6; font: 14px/26px sans-serif; text-align: center; cursor: pointer; user-select: none; opacity: .45 }
    .btn:hover { opacity: 1 }
    .card { position: fixed; top: 38px; left: 6px; width: 250px; background: rgba(15,18,32,.94); color: #e8ecff; border-radius: 12px;
      padding: 12px 14px; font: 12px sans-serif; box-shadow: 0 6px 24px rgba(0,0,0,.5); display: none }
    .card h4 { margin: 0 0 8px; font-size: 13px }
    .fila { margin: 8px 0 2px; display: flex; justify-content: space-between } .fila b { color: #8fb0ff }
    input[type=range] { width: 100%; accent-color: #5b7cff }
    .pre { display: flex; gap: 5px; margin-top: 8px } .pre span { flex: 1; text-align: center; padding: 5px 0; background: #232a4a; border-radius: 6px; cursor: pointer }
    .pre span:hover { background: #3a4a8a }
    .nota { margin-top: 8px; color: #8a94b8; font-size: 10.5px; line-height: 1.35 }`;
  function crear() {
    if (host || !document.body) return;
    host = document.createElement('div'); root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = '<style>' + css + '</style><div class="btn" id="b">⚙</div><div class="card" id="c">' +
      '<h4>Sensibilidad del mouse</h4>' +
      '<div class="fila"><span>General</span><b id="vf"></b></div><input id="f" type="range" min="10" max="800" step="5">' +
      '<div class="fila"><span>Vertical (relativo)</span><b id="vy"></b></div><input id="y" type="range" min="50" max="150" step="5">' +
      '<div class="pre"><span data-v="50">50%</span><span data-v="100">100%</span><span data-v="150">150%</span><span data-v="250">250%</span><span data-v="400">400%</span></div>' +
      '<div class="nota">Esto se multiplica con la sensibilidad de Fortnite (esa no se puede leer desde la app). ' +
      'Si se siente pesado, sube aqui. F9/F10 = menos/mas. Para usar este panel con el mouse, F8 libera el cursor.</div></div>';
    for (const k of ['b', 'c', 'f', 'y', 'vf', 'vy']) el[k] = root.getElementById(k);
    el.b.addEventListener('click', alternar);
    el.f.addEventListener('input', () => S.set(+el.f.value / 100));
    el.y.addEventListener('input', () => S.set(S.get().f, +el.y.value / 100));
    root.querySelectorAll('.pre span').forEach((s) => s.addEventListener('click', () => S.set(+s.dataset.v / 100)));
    document.body.appendChild(host); pintar();
  }
  function alternar() { abierto = !abierto; if (el.c) el.c.style.display = abierto ? 'block' : 'none'; pintar(); }
  function pintar() {
    if (!el.f) return; const g = S.get();
    el.f.value = Math.round(g.f * 100); el.y.value = Math.round(g.y * 100);
    el.vf.textContent = Math.round(g.f * 100) + '%'; el.vy.textContent = Math.round(g.y * 100) + '%';
  }
  window.__novaSensUI = pintar;
  window.addEventListener('keydown', (e) => { if (e.code === 'F4') { crear(); alternar(); e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  const ini = () => crear();
  if (document.body) ini(); else window.addEventListener('DOMContentLoaded', ini);
})();
