(() => {
  'use strict';
  // NOVA v0.12: ocultador del aviso verde "Ctrl+G" (por observador, sin escaneos periodicos) + panel de diagnostico (F1).
  const cnt = { mm: 0, pm: 0, md: 0, mu: 0, pl: 0, tc: 0 };
  let last = '-', verdeInfo = '-';
  const LSP = 'nova_panel_visible', LSV = 'nova_hide_green';
  let verPanel = false, ocultarVerde = true;
  try { verPanel = localStorage.getItem(LSP) === '1'; ocultarVerde = localStorage.getItem(LSV) !== '0'; } catch (_) {}
  const sombras = new Set();

  const nombre = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
    (typeof e.className === 'string' && e.className ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
  const esVerde = (c) => {
    const m = String(c).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
    return !!m && (m[4] === undefined || +m[4] > 0.3) && Math.abs(m[1] - 118) < 35 && Math.abs(m[2] - 185) < 35 && m[3] < 60;
  };
  const raices = () => [document, ...sombras];
  window.__novaRaices = raices;
  const hayStream = () => {
    for (const r of raices()) {
      let vs = []; try { vs = r.querySelectorAll('video'); } catch (_) {}
      for (const v of vs) if (v.videoWidth > 0 && !v.paused) return true;
    }
    return false;
  };
  const oculta = (e) => {
    e.style.setProperty('display', 'none', 'important');
    e.style.setProperty('visibility', 'hidden', 'important');
    e.style.setProperty('pointer-events', 'none', 'important');
  };
  const textoCtrlG = /ctrl\s*\+?\s*g\b/i;

  // ---- revisa UN elemento; devuelve texto si lo oculto ----
  function revisar(e, streaming) {
    const t = e.tagName;
    if (!t || t === 'VIDEO' || t === 'CANVAS' || t === 'HTML' || t === 'BODY' || t === 'SCRIPT' || t === 'STYLE' || t === 'HEAD') return null;
    if (e.style && e.style.display === 'none') return null;
    const w = innerWidth, h = innerHeight;
    // 1) por texto "Ctrl+G": se oculta el contenedor mas grande que solo lleva ese texto
    const tx = e.childElementCount < 6 ? (e.textContent || '').trim() : '';
    if (tx.length > 0 && tx.length < 200 && textoCtrlG.test(tx) && !e.querySelector('video,canvas')) {
      let top = e;
      for (let i = 0; i < 5 && top.parentElement; i++) {
        const p = top.parentElement;
        if (p === document.body || p === document.documentElement) break;
        if ((p.textContent || '').trim().length > tx.length + 10 || p.querySelector('video,canvas')) break;
        top = p;
      }
      const pr = top.getBoundingClientRect();
      if (pr.width < w * 0.6 && pr.height < h * 0.6) { oculta(top); return 'texto ' + nombre(top); }
    }
    // 2) por color: bloque verde NVIDIA mientras hay stream (no botones ni enlaces)
    if (streaming && t !== 'BUTTON' && t !== 'A') {
      const rc0 = e.getBoundingClientRect();
      if (rc0.width < 20 || rc0.height < 20 || rc0.width >= w * 0.6 || rc0.height >= h * 0.6) return null;
      let cs; try { cs = getComputedStyle(e); } catch (_) { return null; }
      let verde = esVerde(cs.backgroundColor) || /118,\s*185,\s*0/.test(cs.backgroundImage);
      if (!verde) for (const ps of ['::before', '::after']) { try { if (esVerde(getComputedStyle(e, ps).backgroundColor)) verde = true; } catch (_) {} }
      if (verde && !e.closest('button,a,[role=button]')) {
        const rc = e.getBoundingClientRect();
        if (rc.width >= 20 && rc.height >= 20 && rc.width < w * 0.6 && rc.height < h * 0.6) {
          oculta(e); return 'color ' + nombre(e) + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height);
        }
      }
    }
    return null;
  }

  // ---- solo se revisan los nodos NUEVOS (lotes), en vez de recorrer toda la pagina cada pocos segundos ----
  let pendientes = new Map(), timer = 0; // nodo -> true si solo hay que mirar ese elemento (sin sus hijos)
  const programar = (n, solo) => { if (!pendientes.has(n) || !solo) pendientes.set(n, !!solo); if (!timer) timer = setTimeout(procesar, 300); };
  function procesar(tope) {
    timer = 0;
    const lote = [...pendientes]; pendientes = new Map();
    if (!ocultarVerde || document.hidden) return;
    const streaming = hayStream(), max = typeof tope === 'number' ? tope : 500;
    let vistos = 0, ultimo = null;
    for (const [n, solo] of lote) {
      if (n.nodeType === 1 && !n.isConnected) continue;
      let lista = [];
      try { lista = n.nodeType === 1 ? (solo ? [n] : [n, ...n.querySelectorAll('*')]) : [...n.querySelectorAll('*')]; } catch (_) {}
      for (const e of lista) {
        if (++vistos > max) break;
        const r = revisar(e, streaming);
        if (r) ultimo = r;
      }
    }
    if (ultimo) verdeInfo = 'verde oculto: ' + ultimo;
    else if (!/oculto/.test(verdeInfo)) verdeInfo = 'verde: nada en el DOM' + (streaming ? '' : ' (sin stream)');
  }
  const mo = new MutationObserver((muts) => {
    if (!ocultarVerde) return;
    for (const m of muts) {
      if (m.type === 'attributes') { if (m.target.nodeType === 1) programar(m.target, true); continue; }
      for (const n of m.addedNodes) {
        if (n.nodeType === 1) programar(n);
        else if (n.nodeType === 3 && m.target.nodeType === 1) programar(m.target, true); // texto que llega despues
      }
    }
  });
  const observar = (raiz) => { try { mo.observe(raiz, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] }); } catch (_) {} };
  observar(document);
  try {
    const o = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (i) {
      const r = o.call(this, i);
      try { sombras.add(r); observar(r); } catch (_) {}
      return r;
    };
  } catch (_) {}
  // respaldo: barrido completo cada 4 s, repartido en rebanadas de ~3 ms para no causar tirones
  let barriendo = false;
  function barridoCompleto() {
    if (barriendo || !ocultarVerde || document.hidden) return;
    barriendo = true;
    const streaming = hayStream();
    let todos = [];
    for (const r of raices()) { try { todos = todos.concat(Array.from(r.querySelectorAll('*'))); } catch (_) {} }
    let i = 0, ultimo = null;
    const rebanada = () => {
      const t0 = performance.now();
      while (i < todos.length && performance.now() - t0 < 3) { const r = revisar(todos[i++], streaming); if (r) ultimo = r; }
      if (i < todos.length) setTimeout(rebanada, 25);
      else { barriendo = false; if (ultimo) verdeInfo = 'verde oculto: ' + ultimo; }
    };
    rebanada();
  }
  setInterval(barridoCompleto, 4000);

  // ---- panel de diagnostico (F1) ----
  const reg = (t, k) => window.addEventListener(t, (e) => {
    if (!verPanel) return;
    cnt[k]++;
    last = t + ' ' + (e.pointerType || '') + (e.isTrusted ? '' : ' (nova)') + ' x' + Math.round(e.clientX) + ' y' + Math.round(e.clientY) +
      ' mv' + e.movementX + ',' + e.movementY + ' b' + e.buttons;
  }, true);
  reg('mousemove', 'mm'); reg('pointermove', 'pm'); reg('mousedown', 'md'); reg('mouseup', 'mu');
  window.addEventListener('touchstart', () => { if (verPanel) cnt.tc++; }, true);
  document.addEventListener('pointerlockchange', () => cnt.pl++);


  // ---- selector manual: F5 oculta lo que haya bajo el cursor (se recuerda); F12 borra lo guardado ----
  const LSH = 'nova_hidden_v1';
  let guardados = []; try { guardados = JSON.parse(localStorage.getItem(LSH) || '[]'); } catch (_) {}
  let px = -1, py = -1;
  for (const t of ['pointermove', 'mousemove', 'pointerdown', 'mousedown']) window.addEventListener(t, (e) => { if (e.clientX != null) { px = e.clientX; py = e.clientY; } }, true);
  const camino = (e) => { // ruta estructural desde la raiz: tag:nth-child(i) > ...
    const partes = [];
    for (let n = e; n && n.nodeType === 1; n = n.parentNode) {
      const p = n.parentNode; if (!p) break;
      let i = 1; for (let s = n.previousElementSibling; s; s = s.previousElementSibling) i++;
      partes.unshift(n.tagName.toLowerCase() + ':nth-child(' + i + ')');
      if (p.nodeType !== 1) break; // llegamos a document o shadow root
    }
    return partes.join(' > ');
  };
  const aplicarGuardados = () => {
    if (!guardados.length) return;
    for (const g of guardados) for (const r of raices()) {
      try { const e = r.querySelector(g.c); if (e && e.style.display !== 'none') oculta(e); } catch (_) {}
    }
  };
  let tAviso = null;
  const aviso2 = (t) => {
    if (!document.body) return;
    let d = document.getElementById('nova-aviso2');
    if (!d) { d = document.createElement('div'); d.id = 'nova-aviso2';
      d.style.cssText = 'position:fixed;top:34px;left:50%;transform:translateX(-50%);z-index:2147483647;background:rgba(0,0,0,.75);color:#fff;font:12px sans-serif;padding:5px 9px;border-radius:6px;pointer-events:none;max-width:80vw';
      document.body.appendChild(d); }
    d.textContent = t; d.style.display = ''; clearTimeout(tAviso); tAviso = setTimeout(() => { d.style.display = 'none'; }, 3500);
  };
  function ocultarBajoCursor() {
    if (px < 0) { aviso2('Mueve el mouse sobre el bloque y pulsa F5'); return; }
    const w = innerWidth, h = innerHeight, c = [];
    for (const r of raices()) {
      let l = []; try { l = r.querySelectorAll('*'); } catch (_) {}
      for (const e of l) {
        const t = e.tagName;
        if (t === 'HTML' || t === 'BODY' || t === 'SCRIPT' || t === 'STYLE' || t === 'VIDEO' || t === 'HEAD') continue;
        if (e.id === 'nova-aviso2' || (e.style && e.style.display === 'none')) continue;
        const rc = e.getBoundingClientRect();
        if (rc.width < 8 || rc.height < 8 || px < rc.left || px > rc.right || py < rc.top || py > rc.bottom) continue;
        if (rc.width >= w * 0.6 || rc.height >= h * 0.6) continue;
        let g = false; try { g = !!e.querySelector('video'); } catch (_) {}
        if (!g) c.push(e);
      }
    }
    const fuera = c.filter((e) => !c.some((o) => o !== e && o.contains(e))); // solo los mas externos
    if (!fuera.length) { aviso2('No encontre nada ahi (' + Math.round(px) + ',' + Math.round(py) + '). Pon el cursor sobre el bloque.'); return; }
    const info = [];
    for (const e of fuera) {
      const rc = e.getBoundingClientRect(), cam = camino(e);
      info.push(nombre(e) + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height));
      if (!guardados.some((g) => g.c === cam)) guardados.push({ c: cam, n: nombre(e) });
      oculta(e);
    }
    try { localStorage.setItem(LSH, JSON.stringify(guardados.slice(-20))); } catch (_) {}
    verdeInfo = 'oculto a mano: ' + info.join(' | ');
    aviso2('Oculto: ' + info.join(' | '));
  }
  setInterval(aplicarGuardados, 1500);

  window.addEventListener('keydown', (e) => {
    if (e.code === 'F1') {
      verPanel = !verPanel;
      try { localStorage.setItem(LSP, verPanel ? '1' : '0'); } catch (_) {}
      e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'F5') { // oculta lo que este bajo el cursor
      ocultarBajoCursor(); e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'F12') { // borra lo ocultado a mano y recarga
      guardados = []; try { localStorage.removeItem(LSH); } catch (_) {}
      aviso2('Borrado. Recargando…'); setTimeout(() => location.reload(), 600);
      e.preventDefault(); e.stopImmediatePropagation();
    } else if (e.code === 'F2') { // activar / desactivar el ocultador del aviso verde
      ocultarVerde = !ocultarVerde;
      try { localStorage.setItem(LSV, ocultarVerde ? '1' : '0'); } catch (_) {}
      verdeInfo = 'ocultar verde: ' + (ocultarVerde ? 'SI' : 'NO');
      e.preventDefault(); e.stopImmediatePropagation();
    }
  }, true);

  let p;
  function pintar() {
    if (!verPanel) { if (p) p.style.display = 'none'; return; }
    if (!document.body) return;
    if (!p) {
      p = document.createElement('div');
      p.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483646;background:rgba(0,0,0,.6);color:#0f0;' +
        'font:10px monospace;padding:3px 5px;border-radius:4px;pointer-events:none;white-space:pre;max-width:60vw';
      document.body.appendChild(p);
    }
    p.style.display = '';
    const lk = window.__novaLocked && window.__novaLocked();
    p.textContent = 'v0.17 mm' + cnt.mm + ' pm' + cnt.pm + ' md' + cnt.md + ' mu' + cnt.mu + ' lock' + cnt.pl + ' touch' + cnt.tc +
      '\n' + (window.NovaNative ? 'captura:' + (lk ? 'SI' : 'no') : 'sin puente nativo') + ' ' + (window.__novaDbg || '') + ' ' + (window.__novaTel ? window.__novaTel() : '') +
      '\n' + last + '\n' + verdeInfo;
  }
  setInterval(pintar, 500);
})();
