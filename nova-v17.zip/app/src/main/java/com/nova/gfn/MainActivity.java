package com.nova.gfn;

import android.app.Activity;
import android.os.Bundle;
import android.view.Choreographer;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends Activity {
    private WebView web;
    private String js = "";
    private String modo = "teclado"; // "teclado" y "tactil" = identidad de PC; "movil" = celular real
    private ScriptHandler scriptHandler;
    private static final String HOME = "https://play.geforcenow.com/";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    // ---- Captura de mouse (estilo maquina virtual) ----
    private float adx, ady, asx, asy;      // movimiento / scroll acumulado
    private int curMask = 0, sentMask = 0; // botones (mismos bits que MouseEvent.buttons)
    private boolean flushPend = false;
    // se manda a la pagina una sola vez por cuadro de pantalla (en vez de cada pocos ms)
    private final Choreographer.FrameCallback frameCb = new Choreographer.FrameCallback() {
        @Override public void doFrame(long t) { flush(); }
    };
    private int refresco = 60; // Hz pedidos a la pantalla (60 por defecto: estable con un stream de 60 FPS)

    private String leer(String f) {
        try (InputStream in = getAssets().open(f)) {
            byte[] b = new byte[in.available()]; in.read(b); return new String(b, "UTF-8") + "\n";
        } catch (Exception e) { return ""; }
    }

    /** Lo llama el JS (capture.js) para pedir / soltar la captura del mouse. */
    public class Bridge {
        @JavascriptInterface public void setModo(final String m) {
            final String nuevo = "movil".equals(m) ? "movil" : "tactil".equals(m) ? "tactil" : "teclado";
            runOnUiThread(new Runnable() { @Override public void run() { cambiarModo(nuevo); } });
        }
        @JavascriptInterface public String modo() { return modo; }
        @JavascriptInterface public void setRefresco(final int hz) {
            runOnUiThread(new Runnable() { @Override public void run() { cambiarRefresco(hz); } });
        }
            @JavascriptInterface public void capture(final boolean on) {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (on) { web.requestFocus(); web.requestPointerCapture(); }
                else web.releasePointerCapture();
            } });
        }
    }

    private int nEv = 0, lastAct = -1, lastSrc = 0;
    private boolean usoRel = false;

    private void addMove(MotionEvent ev) {
        boolean relSrc = (ev.getSource() & android.view.InputDevice.SOURCE_MOUSE_RELATIVE) == android.view.InputDevice.SOURCE_MOUSE_RELATIVE;
        int n = ev.getHistorySize();
        for (int i = 0; i <= n; i++) {
            float rx, ry, gx, gy;
            if (i < n) {
                rx = ev.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_X, i); ry = ev.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_Y, i);
                gx = ev.getHistoricalX(i); gy = ev.getHistoricalY(i);
            } else {
                rx = ev.getAxisValue(MotionEvent.AXIS_RELATIVE_X); ry = ev.getAxisValue(MotionEvent.AXIS_RELATIVE_Y);
                gx = ev.getX(); gy = ev.getY();
            }
            if (rx != 0 || ry != 0) { adx += rx; ady += ry; usoRel = true; }
            else if (relSrc) { adx += gx; ady += gy; usoRel = false; }
        }
    }

    private String construirJs(String m) {
        return "window.__novaModo='" + m + "';window.__novaRefresco=" + refresco + ";window.__novaRefrescos='" + listaRefrescos() + "';\n"
            + leer("pcmode.js") + leer("capture.js") + leer("sens.js") + leer("diag.js") + leer("fit.js");
    }

    /** Desktop (Windows) para teclado y mouse; Chrome movil para tactil. */
    private String uaPara(String m) {
        if ("movil".equals(m)) return WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        return UA;
    }

    /** Vuelve a registrar los scripts de inicio (por ejemplo tras cambiar un ajuste guardado). */
    private void reinyectar() {
        js = construirJs(modo);
        if (scriptHandler != null) { scriptHandler.remove(); scriptHandler = null; }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
    }

    /** Frecuencias de refresco disponibles en la resolucion actual, p. ej. "60,90,120". */
    private String listaRefrescos() {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode();
            java.util.TreeSet<Integer> set = new java.util.TreeSet<Integer>();
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight())
                    set.add(Math.round(m.getRefreshRate()));
            }
            StringBuilder sb = new StringBuilder();
            for (int r : set) { if (sb.length() > 0) sb.append(','); sb.append(r); }
            return sb.length() > 0 ? sb.toString() : "60";
        } catch (Exception e) { return "60"; }
    }

    private void aplicarRefresco(int hz) {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode(), mejor = null;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                if (mejor == null || Math.abs(m.getRefreshRate() - hz) < Math.abs(mejor.getRefreshRate() - hz)) mejor = m;
            }
            if (mejor == null) return;
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredRefreshRate = mejor.getRefreshRate();
            lp.preferredDisplayModeId = mejor.getModeId();
            getWindow().setAttributes(lp);
        } catch (Exception ignored) { }
    }

    private void cambiarRefresco(int hz) {
        refresco = hz;
        getSharedPreferences("nova", MODE_PRIVATE).edit().putInt("refresco", hz).apply();
        aplicarRefresco(hz);
        reinyectar();
    }

    private void cambiarModo(String nuevo) {
        if (nuevo.equals(modo)) return;
        boolean recargar = !uaPara(modo).equals(uaPara(nuevo)); // solo cambia la identidad al ir o volver de "movil"
        modo = nuevo;
        getSharedPreferences("nova", MODE_PRIVATE).edit().putString("modo", nuevo).apply();
        web.releasePointerCapture();
        reinyectar();
        if (recargar) {
            web.getSettings().setUserAgentString(uaPara(modo));
            web.loadUrl(HOME);
        }
    }

    private void captured(MotionEvent ev) {
        nEv++; lastAct = ev.getActionMasked(); lastSrc = ev.getSource();
        addMove(ev);
        if (ev.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            asx += ev.getAxisValue(MotionEvent.AXIS_HSCROLL);
            asy += ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
        }
        int b = ev.getButtonState();
        if (b != curMask) { curMask = b; flush(); return; } // cambio de boton: se manda ya, sin juntar
        if (!flushPend) { flushPend = true; Choreographer.getInstance().postFrameCallback(frameCb); }
    }

    private void flush() {
        flushPend = false; Choreographer.getInstance().removeFrameCallback(frameCb);
        if (adx == 0 && ady == 0 && asx == 0 && asy == 0 && curMask == sentMask) return;
        String dbg = "n" + nEv + " a" + lastAct + " s" + Integer.toHexString(lastSrc) + (usoRel ? " rel" : " xy");
        String s = "window.__novaIn&&window.__novaIn(" + adx + "," + ady + "," + curMask + "," + asx + "," + asy + ",'" + dbg + "')";
        adx = ady = asx = asy = 0; sentMask = curMask;
        web.evaluateJavascript(s, null);
    }

    @Override public void onPointerCaptureChanged(boolean has) {
        super.onPointerCaptureChanged(has);
        if (!has) { adx = ady = asx = asy = 0; curMask = 0; sentMask = 0; }
        if (web != null) web.evaluateJavascript("window.__novaCap&&window.__novaCap(" + has + ")", null);
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        modo = "teclado"; // Lite: siempre identidad de PC; no se toca la frecuencia de pantalla
        js = construirJs(modo);
        web = new WebView(this);
        setContentView(web);
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        web.addJavascriptInterface(new Bridge(), "NovaNative");
        web.setOnCapturedPointerListener(new View.OnCapturedPointerListener() {
            @Override public boolean onCapturedPointer(View v, MotionEvent ev) { captured(ev); return true; }
        });
        WebSettings st = web.getSettings();
        st.setSafeBrowsingEnabled(false);
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setUserAgentString(uaPara(modo));
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);
        web.setWebChromeClient(new WebChromeClient());
        boolean doc = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (doc) scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, js, Collections.singleton("https://*.geforcenow.com"));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap b) {
                if (!doc && url != null && url.contains("geforcenow.com")) v.evaluateJavascript(js, null);
            }
        });
        web.loadUrl(HOME);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
